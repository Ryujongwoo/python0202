library(dplyr)
library(ggplot2)
df_excel_exam_dplyr <- df_excel_exam

# summarise() 함수와 group_by() 함수를 사용하는 그룹별로 요약하기
# 데이터를 그룹으로 묶에 요약할 때 반드시 group_by() 함수로 먼저 그룹으로
# 묶어주고 summarise() 함수를 사용해서 요약해야 한다.
df_excel_exam_dplyr %>% 
    group_by(class) %>% 
    summarise(mean_math = mean(math))

df_excel_exam_dplyr %>% 
    group_by(class) %>% 
    summarise(
        합계 = sum(math),
        평균 = mean(math),
        중위수 = median(math),
        개수 = n(), # 개수를 얻어오는 함수는 인수를 지정하지 않는다.
        최대값 = max(math),
        최소값 = min(math),
        분산 = var(math),
        표준편차 = sd(math)
    )

# mpg에서 자동차 회사별로 그룹화, 같은 회사에서는 구동 방식(drv)별로 그룹화,
# 구동 방식도 같으면 차종(class)별로 그룹화 한 후 도시 주행 연비 평균을 계산
# 한다.
mpg %>% 
    group_by(manufacturer, drv, class) %>% 
    summarise(cty_mean = mean(cty))

# 자동차 회사별로 차종이 suv인 자동차의 도시 및 고속도로 연비의 평균을 계산해서
# 내림차순으로 정렬한 후 상위 5개를 얻어온다.
mpg %>% 
    filter(class == 'suv') %>% 
    group_by(manufacturer) %>% 
    mutate(avg = (cty + hwy) / 2) %>% 
    summarise(avg_mean = mean(avg)) %>% 
    arrange(desc(avg_mean)) %>% 
    head(5)

# 차종별로 도시 연비의 평균을 계산해서 평균이 높은 순서로 얻어온다.
mpg %>% 
    group_by(class) %>% 
    summarise(cty_mean = mean(cty)) %>% 
    arrange(desc(cty_mean))

# 고속도로 연비의 평균이 가장 높은 회사 3곳을 얻어온다.
mpg %>% 
    group_by(manufacturer) %>% 
    summarise(hwy_mean = mean(hwy)) %>% 
    arrange(desc(hwy_mean)) %>% 
    head(3)

# 각 회사별 경차(compact)의 차종 수를 내림차순으로 정렬해 얻어온다.
mpg %>% 
    filter(class == 'compact') %>% 
    group_by(manufacturer) %>% 
    summarise(count = n()) %>% 
    arrange(desc(count))

# left_join() 함수로 데이터 프레임을 가로 방향으로 데이터 합치기를 할 수 있다.
# left_join(데이터 프레임1, 데이터 프레임2, by = '기준 변수명')
test1 <- data.frame(id = c(1, 2, 3, 4, 5), middle = c(60, 80, 70, 90, 85))
test2 <- data.frame(id = c(1, 2, 3, 4, 5), final = c(70, 83, 65, 95, 80))

# by 옵션에는 합칠 때 기준이 되는 변수의 이름을 입력해야 하며 합쳐질 두 개의
# 데이터 프레임에 반드시 같은 이름의 변수가 있어야 한다.
left_join(test1, test2, by = 'id')
# by 옵션을 지정하지 않으면 R이 알아서 같은 이름의 변수를 기준으로 합치기를
# 실행한다.
left_join(test1, test2)

# left_join() 함수로 데이터 프레임의 합치기를 할 때 두 개의 데이터 프레임의
# 행(데이터)의 개수가 반드시 같아야 할 필요없다.
df_excel_exam_join <- df_excel_exam
df_teacher_name = data.frame(class = c(1, 2, 3, 4, 5),
            teacher = c('홍길동', '임꺽정', '장길산', '일지매', '루팡'))
left_join(df_excel_exam_join, df_teacher_name, by = 'class')
left_join(df_excel_exam_join, df_teacher_name)

# bind_rows() 함수로 데이터 프레임을 세로 방향으로 데이터 합치기를 할 수 있다.
# bind_rows() 함수로 세로 방향으로 합칠 데이터 프레임의 모든 변수 이름이 같아야
# 정상적으로 합치기가 실행된다.
# bind_rows(데이터 프레임1, 데이터 프레임2)
group1 <- data.frame(id = c(1, 2, 3, 4, 5), test = c(60, 80, 70, 90, 85))
group2 <- data.frame(id = c(1, 2, 3, 4, 5), test = c(70, 83, 65, 95, 80))
bind_rows(group1, group2)

#############################################################################

# 데이터 정제
# 데이터 정제는 빠진 데이터(결측치) 또는 이상한 데이터(이상치)를 제거하는 작업
# 이다.
# 빠진 데이터 => 측정이 안된 데이터 => 업는 데이터 => NA => 결측치
# NA는 따옴표로 묶으면 안된다. => 결측치가 아닌 문자열 데이터로 취급된다.
# 문자열 결측치는 <NA>로 표시되고 문자열을 제외한 나머지는 NA로 표시된다.
df_na <- data.frame(gender = c('M', 'F', NA, 'F', 'M'),
                    score = c(5, 4, 3, 2, NA))

# is.na() 함수로 데이터에 결측치가 포함되어 있는가 확인할 수 있다.
# 결측치는 TRUE, 결측치가 아니면 FALSE로 표시된다.
is.na(df_na)

# is.na() 함수 table() 함수를 사용해서 결측치의 빈도수를 파악할 수 있다.
table(is.na(df_na))
table(is.na(df_na$gender))
table(is.na(df_na$score))

# 결측치가 포함된 데이터를 함수에 적용시키면 정상적으로 연산되지 않고 NA가
# 출력된다. => 정상적인 연산을 하려면 결측치를 제외시켜야 한다.
sum(df_na$score) # NA
mean(df_na$score) # NA

# 결측치 처리방법

# 1. dplyr 패키지의 filter() 함수를 사용해서 결측치를 제외한 데이터만 추출한다.
df_no_na <- df_na %>% filter(is.na(gender)) # NA인 데이터만 추출된다.
df_no_na <- df_na %>% filter(!is.na(gender))
df_no_na <- df_no_na %>% filter(!is.na(score))
# gender가 NA가 아니고 score가 NA가 아닌 데이터만 추출한다.
df_no_na <- df_na %>% filter(!is.na(gender) & !is.na(score))
sum(df_no_na$score)
mean(df_no_na$score)

# 2. na.omit() 함수를 사용해서 결측치가 있는 모든 행을 한꺼번에 제거할 수 있다.
df_no_na <- na.omit(df_na)

# 3. 함수를 실행할 때 na.rm = T 속성을 지정하면 결측치를 제외하고 함수를 실행
# 한다.
sum(df_na$score) # NA
sum(df_na$score, na.rm = T)
mean(df_na$score, na.rm = T)
max(df_na$score, na.rm = T)
min(df_na$score, na.rm = T)

# 개수를 세는 length() 함수에는 na.rm = T 속성을 사용할 수 없다. => NA도 개수에
# 포함된다.
length(df_na$score) # 5
length(df_na$score, na.rm = T) # 인수를 1개만 써야하기 때문에 에러 발생

df_excel_exam_na <- df_excel_exam
df_excel_exam_na[c(3, 8, 15), 'math'] <- NA
df_excel_exam_na[20, 'science'] <- NA

# na.rm = T 속성은 dplyr 패키지의 summarise() 함수에 사용하는 그룹 함수에서도
# 사용이 가능하다.
# 그룹 함수 중 데이터의 개수를 세는 n() 함수에서는 na.rm = T 속성을 사용할 수
# 없다. => 개수에는 NA더 포함되서 계산된다.
df_excel_exam_na %>% 
    group_by(class) %>% 
    summarise(
        math_sum = sum(math, na.rm = T),
        math_mean = mean(math, na.rm = T),
        math_median = median(math, na.rm = T),
        # math_n = n(na.rm = T) # 인수를 쓰면 안되기 때문에 에러가 발생된다.
        math_n = n()
    )

# summarise() 함수에서 n() 함수가 실행되지 않으면 length() 함수를 사용한다.
df_excel_exam_na %>% 
    group_by(class) %>% 
    summarise(
        math_sum = sum(math, na.rm = T),
        math_mean = mean(math, na.rm = T),
        math_median = median(math, na.rm = T),
        # math_n = n()
        math_n = length(math)
    )

# summarise() 함수를 사용하지 않고 개수만 계산을 해야 한다면 tally() 함수를
# 사용해도 된다. => n 이라는 변수가 자동으로 만들어진다.
df_excel_exam_na %>% 
    group_by(class) %>% 
    tally()

# 4. 결측치의 개수를 세지 않으려면 filter() 함수를 사용해서 결측치를 걸러내고
# 계산하면 된다. => na.rm = T 속성을 사용할 필요없다.
df_excel_exam_na %>% 
    filter(!is.na(math)) %>% # math 열의 결측치를 걸러낸다.
    group_by(class) %>% 
    summarise(
        math_sum = sum(math),
        math_mean = mean(math),
        math_median = median(math),
        math_n = n()
    )

# 5. filter() 함수를 사용하지 않고 결측치를 걸러내려면 원본 데이터 프레임에
# na.omit() 함수를 적용시켜 파이프(%>%)로 넘겨주면 된다.
# na.omit() 함수를 사용했기 때문에 math 열의 NA만 걸러내는 것이 아니고 모든
# 열의 NA를 걸러낸다. => science 열의 NA도 걸러낸다.
na.omit(df_excel_exam_na) %>% 
    group_by(class) %>% 
    summarise(
        math_sum = sum(math),
        math_mean = mean(math),
        math_median = median(math),
        math_n = n()
    )

# 6. ifelse() 함수를 사용해서 결측치를 결측치가 아닌 데이터의 평균이나 중위수로
# 대체시켜 사용한다.

# NA를 제외한 math와 science의 평균을 계산한다.
mean(df_excel_exam_na$math, na.rm = T) # 55.23529 => 55
mean(df_excel_exam_na$science, na.rm = T) # 59.52632 => 60

# math의 3, 8, 15 번째 데이터를 NA에서 NA를 제외한 math의 평균으로 대체하고
# science 20번째 데이터를 NA에서 NA를 제외한 science의 평균으로 대체한다.
df_excel_exam_na$math <- 
    ifelse(
        is.na(df_excel_exam_na$math),
        mean(df_excel_exam_na$math, na.rm = T), 
        df_excel_exam_na$math
    )
df_excel_exam_na$science <- 
    ifelse(
        is.na(df_excel_exam_na$science),
        mean(df_excel_exam_na$science, na.rm = T), 
        df_excel_exam_na$science
    )

#############################################################################

# 이상한 데이터 : 극단치, 이상점, outlier
# 이상한 데이터는 존재할 수 없는 값이 데이터에 포함되어 있음을 의미한다.
# 발견된 이상한 데이터는 결측치로 변환한 후 제거하거나 다른 값으로 대체한다.

# gender는 1과 2만 데이터로 가질 수 있고 score는 1, 2, 3, 4, 5만 데이터로 가질
# 수 있다.
outlier <- data.frame(gender = c(1, 2, 1, 3, 1, 2),
                      score = c(5, 4, 3, 2, 4, 6))
# table() 함수를 사용해서 이상치가 존재하는가 확인한다.
table(outlier$gender)
table(outlier$score)

# 이상치가 존재할 경우 ifelse() 함수로 이상치를 결측치로 변환한다.
outlier$gender <- ifelse(outlier$gender > 2, NA, outlier$gender)
outlier$score <- ifelse(outlier$score > 5, NA, outlier$score)

# ggplot2 패키지에 내장된 데이터를 사용하다 손상시킨 경우 패키지에서 다시 
# 꺼내오면 된다.
mpg <- ggplot2::mpg # ggplot2 패키지의 mpg 데이터를 다시 꺼내온다.

# boxplot() 함수를 참고해서 ggplot2 패키지의 mpg 데이터에서 hwy 변수에 저장된
# 데이터중에서 극단치를 결측치로 변환한다.
boxplot(mpg$hwy)
boxplot(mpg$hwy)$stats
#      [,1]
# [1,]   12 # 최소값
# [2,]   18 # 1사분위수
# [3,]   24 # 평균
# [4,]   27 # 3사분위수
# [5,]   37 # 최대값
# boxplot(mpg$hwy)$stats 실행 결과에서 12 미만이거나 37을 초과하는 경우는
# 이상한 데이터일 확률이 매우 높다.
mpg$hwy <- ifelse(mpg$hwy < 12 | mpg$hwy > 37, NA, mpg$hwy)







