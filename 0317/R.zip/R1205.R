# 정적 웹 스크레이핑(크롤링)
# 네이버 영화 사이트 데이터 중에서 영화 제목, 평점, 리뷰만 추출해서 csv 파일에
# 저장한다.

# 타겟 사이트 : https://movie.naver.com/movie/point/af/list.nhn?&page=1
# 영화 제목 => class='movie'
# 영화 평점 => td > div > em
# 영화 리뷰 => class='title' => 가공작업

# 1. 웹 스크레이핑에 사용할 패키지를 설치하고 로드한다.
install.packages('rvest')
library(rvest)

# 2. 스크레이핑 할 웹 사이트 주소를 지정한다.
url <- 'https://movie.naver.com/movie/point/af/list.nhn?&page=1'

# 3. read_html() 함수로 인수로 지정한 웹 사이트 전체 내용을 읽는다. => 수집
# encoding = 'CP949' 옵션을 지정해서 한글이 깨지지 않도록 한다.
content <- read_html(url, encoding = 'CP949')
class(content)

# 4. html_nodes() 함수로 읽어온 html 문서에서 필요한 데이터를 읽는다.
# html_nodes(웹 사이트 내용 전체를 기억하는 변수, 선택자)
# class 속성이 지정된 데이터를 읽어야 하므로 앞에 반드시 '.'을 찍어야 한다.
nodes <- html_nodes(content, '.movie')

# 5. html_text() 함수로 trim = T 옵션을 지정해 불필요한 빈 칸은 제거하고 필요한
# 텍스트만 얻어온다.
movie <- html_text(nodes, trim = T)
movie

# 6. 평점은 td > div > em(td의 자식 div의 자식 em)을 사용해서 읽어들인다.
nodes <- html_nodes(content, 'td > div > em')
point <- html_text(nodes, trim = T)
point

# 7. 리뷰는 네이버 영화 사이트가 리뉴얼 되면서 읽어들일 리뷰에 css 선택자가
# 없어져서 아래와 같이 읽어 리뷰만 뽑아낸다. => 정제
nodes <- html_nodes(content, '.title')
title <- html_text(nodes, trim = T)
# 읽어들인 내용에서 제어문자(\t, \n)를 제거한다.
title <- gsub('[[:cntrl:]]', '', title)
# strsplit() 함수를 사용해서 영화제목, 평점과 리뷰를 분리시킨다. 함수의 실행
# 결과는 list 타입이 된다.
title <- strsplit(title, '중[0-9]{1,2}')
class(title) # list
# strsplit() 함수 실행 결과를 unlist() 함수를 사용해 벡터로 바꿔준다.
title <- unlist(title)
class(title) # character
title <- gsub('신고', '', title)
# 리뷰를 기억할 빈 변수를 선언한다.
review = NULL
for(i in seq(2, 20, by = 2)) {
    review = c(review, title[i])
}
review

# cbind() 함수를 사용해서 제목, 평점, 리뷰를 합친다.
page <- cbind(movie, point)
page <- cbind(page, review)
page
class(page) # matrix

# 데이터 처리를 위해서 데이터 프레임 형태로 변환시킨다.
page <- as.data.frame(page)
class(page) # data.frame

# 웹 스크레이핑 된 데이터를 csv 파일로 저장시킨다.
write.csv(page, 'movie_review.csv')

#############################################################################

# for를 이용하는 반복처리

# for(변수명 in 반복횟수) {
#     반복할 문장
#     ...
# }

# i가 1부터 5까지 1씩 증가하면서 반복한다.
for(i in 1:5) {
    print(i)
}

# i가 5부터 1까지 1씩 감소하면서 반복한다.
for(i in 5:1) {
    print(i)
}

# i가 1, 3, 5, 7, 9로 변경되며 반복한다.
for(i in c(1, 3, 5, 7, 9)) {
    print(i)
}
# seq(초기치, 최종치, by = 증가치)
# by 옵션이 생략되면 증가치는 1이 기본값이고 by를 생략하고 증가치만 쓸 수 있다.
for(i in seq(1, 10, by = 2)) {
    print(i)
}
for(i in seq(1, 10, 2)) {
    print(i)
}
# i가 10 부터 1까지 2씩 감소하며 반복한다.
for(i in seq(10, 1, -2)) {
    print(i)
}

#############################################################################

# 반복문을 사용해서 여러 페이지 읽어오기

library(rvest)
# 웹 스크레이핑 할 때 변경되지 않는 주소 부분을 저장해둔다.
site <- 'https://movie.naver.com/movie/point/af/list.nhn?&page='
# 여러 페이지에서 읽어온 리뷰를 합칠 기억 장소를 선언하고 NULL로 초기화한다.
movie_review = NULL
# 읽어올 페이지 분량 만큼 반복하며 리뷰를 읽는다.
for(i in 1:100) {
    # print(paste(site, i, sep = ''))
    # paste() 함수로 번경되지 않는 주소와 변경되는 주소를 이어 붙어셔 읽어들일
    # 주소를 만든다.
    url <- paste(site, i, sep = '')
    print(url)
    
    content <- read_html(url, encoding = 'CP949')
    # 한 페이지를 읽어들인 후 다음 페이지가 로딩되는 시간동안 잠깐 스크레이핑을
    # 멈춰주는 동작이 필요하다. => 페이지가 전환된 후 넣어준다.
    Sys.sleep(1) # 시간은 초 단위로 지정한다.
    
    nodes <- html_nodes(content, '.movie')
    movie <- html_text(nodes, trim = T)
    nodes <- html_nodes(content, 'td > div > em')
    point <- html_text(nodes, trim = T)
    nodes <- html_nodes(content, '.title')
    title <- html_text(nodes, trim = T)
    title <- gsub('[[:cntrl:]]', '', title)
    title <- strsplit(title, '중[0-9]{1,2}')
    title <- unlist(title)
    title <- gsub('신고', '', title)
    review = NULL
    for(i in seq(2, 20, by = 2)) {
        review = c(review, title[i])
    }
    
    # 리뷰 작성일을 얻어온다.
    # 글번호에 지정된 클래스가 num과 ac이고 네티즌 최고 평점에 지정된 클래스가
    # num과 b이고 실제 읽어야 할 작성일에 지정된 클래스가 num 이다.
    # .num만 사용하면 작성일만 읽어오는 것이 아니고 글번호와 네티즌 최고 평점도
    # 읽어오기 때문에 제외 선택자(not)사용해서 ac, b 클래스를 가지는 부분은
    # 읽어오지 않도록 설정했다.
    nodes <- html_nodes(content, '.num:not(.ac):not(.b)')
    temp <- html_text(nodes, trim = T)
    # temp에는 'jwj0****19.12.05'와 같은 형태의 데이터가 저장되어있고 작성일만
    # 뽑아내야 하기 때문에 substr() 함수를 사용해 작성일만 뽑아낸다.
    # substr(문자열, 시작위치, 종료위치)
    date = NULL
    for(j in 1:10) {
        # print(substr(temp[j], 9, 16))
        date <- c(date, substr(temp[j], 9, 16))
    }
    
    # cbind() 함수를 사용해서 제목, 평점, 리뷰, 작성일을 합친다.
    page <- cbind(movie, point)
    page <- cbind(page, review)
    page <- cbind(page, date)
    # print(page)
    
    # 여러 페이지의 리뷰 결과를 기억할 movie_review에 rbind() 함수를 사용해
    # 한 페이지씩 스크레이핑 한 데이터를 합쳐준다.
    movie_review <- rbind(movie_review, page)
}

# 최종 스크레이핑된 데이터는 matrix 타입이기 때문에 데이터 처리를 위해서 데이터
# 프레임 타입으로 변환시킨다.
movie_review <- as.data.frame(movie_review)
class(movie_review)
# 웹 스크레이핑된 데이터를 csv 파일로 저장한다.
write.csv(movie_review, 'movie_review.csv')

#############################################################################

# csv 파일을 read.csv() 함수로 읽으면 데이터 프레임 타입으로 읽어오므로 별도로
# 데이터 프레임으로 데이터 타입을 변경시킬 필요없다.
movie_review <- read.csv('movie_review.csv')
class(movie_review) # data.frame
class(movie_review$movie) # factor
# csv 파일의 데이터를 read.csv() 함수로 읽어오면 문자 데이터는 베터가 아닌 펙터
# 타입으로 읽어오기 때문에 stringsAsFactors = F 옵션을 지정해서 읽거나
# as.character() 함수를 사용해서 펙터 타입의 데이터를 일일히 벡터 타입으로
# 변환한 후 작업한다.
movie_review <- read.csv('movie_review.csv', stringsAsFactors = F)
class(movie_review) # data.frame
class(movie_review$movie) # character

# 1 페이지 부터 100 페이지 까지 읽어들인 네이버 영화 리뷰 데이터를 이용해
# 영화별 평점 그래프를 출력한다.

library(dplyr)
movie_review_mean <- movie_review %>% 
    group_by(movie) %>% 
    summarise(count = n(), mean = round(mean(point), 2)) %>% 
    filter(count >= 5) %>% 
    arrange(desc(count)) %>% 
    head(10)

library(ggplot2)
ggplot(movie_review_mean, aes(reorder(movie, count), mean)) +
    geom_col() +
    coord_flip() +
    ggtitle('네이버 영화 평점 순위') +
    xlab('영화 제목') +
    ylab('평점') +
    geom_text(aes(label = count), hjust = -0.3) +
    geom_text(aes(label = mean), hjust = 2.0, size = 8, color = 'white')

#############################################################################

# XML 패키지를 이용해 웹 스크레이핑 하기
install.packages('XML')
library(XML)
install.packages('httr')
library(httr)

# 한국일보 최신 뉴스 제목 스크레이핑

# httr 패키지의 GET() 함수로 스크레이핑 할 페이지의 전체 소스를 얻어온다.
hankook <- GET('https://www.hankookilbo.com/')
# XML 패키지의 htmlParse() 함수로 GET() 함수로 얻어온 소스 코드를 스크레이핑 
# 할 수 있는 상태로 변환한다.
hankook <- htmlParse(hankook)

# xpathSApply() 함수로 특정 태그의 class 속성을 가지는 텍스트를 얻어온다.
# //태그이름[@class='클래스이름']/태그이름
content <- xpathSApply(hankook, 
           '//div[@class="news-list-container"]/ul/li/p/a', xmlValue)
content <- xpathSApply(hankook, 
           '//div[@class="news-list-container"]/ul/li/p[@class="title "]/a',
                       xmlValue)
content <- gsub('[[:punct:][:cntrl:]]', '', content)

#############################################################################

# 한국일보 최신 뉴스의 제목

domain <- 'https://www.hankookilbo.com'
hankook <- GET(domain)
hankook <- htmlParse(hankook)

# xmlValue는 태그 내부의 텍스트를 얻어온다.
content <- xpathSApply(hankook, 
           '//div[@class="news-list-container"]/ul/li/p[@class="title "]/a',
           xmlValue)
library(stringr)
# str_trim() 함수를 사용해 문자열 앞, 뒤의 공백을 제거할 수 있다.
# str_trim(공백을 제거할 문자열, 공백을 제거할 방향)
# 공백을 제거할 방향은 both(양쪽), left(왼쪽), right(오른쪽)이 있다.
content <- str_trim(gsub('[[:punct:][:cntrl:]]', '', content), 'both')

# 한국일보 최신 뉴스의 url
# xmlGetAttr는 xpathSApply() 함수의 4번째 인수로 지정된 속성의 값을 얻어온다.
link <- xpathSApply(hankook, 
        '//div[@class="news-list-container"]/ul/li/p[@class="title "]/a',
        xmlGetAttr, 'href')

for(i in 2:length(content)) {
    print(content[i])
    news_link <- paste(domain, link[i], sep = '')
    print(news_link)
    
    news_content <- GET(news_link)
    news_content <- htmlParse(news_content)
    news_content <- xpathSApply(news_content,
                    '//div[@class="article-story"]', xmlValue)
    news_content <- str_trim(gsub('[[:punct:][:cntrl:]]', '', 
                    news_content), 'both')
    print(news_content)
    line <- paste('================== ', i, ' ==================', sep = '' )
    print(line)
}

# xpath를 사용해서 크롤링을 할 경우 크롬에서 xpath를 복사해 오는 경우 아래와 
# 같이 요소가 한 개 밖에 없는 부분에서 정상적으로 처리가 되지 않는다.
# //*[@id="content"]/div[1]/div[1]/section[2]/div[1]/div/div/ul/li[1]/p[1]/a
# div[1] 아래의 div 부터 정상적으로 작동되지 않는다.
# 해결 방법은 아래와 같이 정상적으로 작동되지 않는 부분을 제거하고 '//'를
# 입력한 후 읽어들일 데이터가 포함된 태그를 적어주면 된다.
xpath <- '//*[@id="content"]/div[1]/div[1]/section[2]/div[1]//a'
content <- xpathSApply(hankook, xpath, xmlValue)
content <- gsub('[[:punct:][:cntrl:]]', '', content)









