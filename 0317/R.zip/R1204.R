# 대한민국 시도별 인구, 결핵 환자 수 단계 구분도 만들기
# kormaps2014 패키지를 이용하면 대한민국의 지역 통계 데이터와 지도 데이터를 
# 사용할 수 있다.
# 어떤 패키지들은 CRAN에 등록되어있지 않고 github를 통해 공유된다.
# github에 공유된 kormaps2014 패키지를 다운받아 사용하려면 devtools 패키지를 
# 설치하고 다운받아 사용한다.
library(rJava)
install.packages('devtools')
library(devtools)
# devtools 패키지의 install_github() 함수로 kormaps2014 패키지를 설치한다.
install_github('cardiomoon/kormaps2014')
library(kormaps2014)

# 지도 데이터 => kormap1(시도별), kormap2(시구군별), kormap3(읍면동별)
# 한글이 깨져서 보이면 kormaps2014 패키지의 changeCode() 함수를 사용해 출력하면
# UTF-8로 인코딩된 한글을 CP949로 변환해서 깨지지 않게 출력한다.
head(kormap1, 3)
head(changeCode(kormap1), 3)
# 인구 데이터 => korpop1(시도별), korpop2(시군구별), korpop3(읍면동별)
head(korpop1, 3)
head(changeCode(korpop1), 3)

# kormaps2014 패키지로 단계 구분도 작성시 오류가 발생된다면 stringi 패키지가
# 설치되지 않아서 그렇기 때문에 stringi 패키지를 설치하고 로드한다.
install.packages('stringi')
library(stringi)

str(changeCode(kormap1))
str(changeCode(korpop1))
# 변수 이름이 한글일 경우 오동작을 일으킬 수 있으므로 지도 작성에 사용할 변수의
# 이름을 dplyr 패키지의 rename() 함수로 영문으로 변환한다.
library(dplyr)
korpop1_kp <- korpop1
korpop1_kp <- rename(korpop1_kp, name = 행정구역별_읍면동, pop = 총인구_명)
str(changeCode(korpop1_kp))

library(ggplot2)
library(ggiraphExtra)
library(mapproj)
# ggChoropleth() 함수로 만든 단계 구분도에서 한글이 깨져보이면 options() 함수를
# 사용해 UTF-8로 인코딩 시킨다. => 원상 복구는 CP949로 인코딩하면 된다.
# options() 함수는 R을 다시 시작하면 원상 복구된다.
options(encoding = 'UTF-8')

# kormap1와 korpop1_kp를 이용해 단계 구분도를 만든다.
ggChoropleth(data = korpop1_kp, aes(fill = pop, map_id = code), map = kormap1)
# 단계 구분도위에 마우스를 올렸을 때 tooltip을 표시되게 하려면 tooltip 속성에
# tooltip으로 사용할 변수명을 적어주고 interactive = T 속성을 지정하면 된다.
ggChoropleth(data = korpop1_kp, aes(fill = pop, map_id = code, tooltip = name),
             map = kormap1, interactive = T)

#############################################################################

# 위와 같은 방법으로 실행했는데 interactive 그래프에 tooltip의 한글이 박살나면
# 아래와 같은 방법으로 만든다.

areacode <- kormaps2014::areacode
korpop1_kp2 <- korpop1
str(changeCode(korpop1_kp2))
class(areacode) # data.frame
areacode # 지역 코드에 따른 지역 이름이 저장된 데이터 프레임
changeCode(areacode)

# 아래와 같이 left_join() 함수를 실행하면 korpop1_kp2의 code는 character 타입
# 이고 areacode의 code는 integer 타입이므로 에러가 발생된다.
# korpop1_kp2 <- left_join(korpop1_kp2, areacode, by = 'code')
class(korpop1_kp2$code) # character
class(areacode$code) # integer

# areacode의 code를 as.character() 함수를 사용해 character 타입으로 변환한다.
areacode_kp <- areacode
areacode_kp$code <- as.character(areacode$code)
class(areacode_kp$code) # character
korpop1_kp2 <- left_join(korpop1_kp2, changeCode(areacode_kp), by = 'code')
korpop1_kp2 <- rename(korpop1_kp2, pop = 총인구_명)

ggChoropleth(data = korpop1_kp2, aes(fill = pop, map_id = code), map = kormap1)
ggChoropleth(data = korpop1_kp2, aes(fill = pop, map_id = code, 
                                     tooltip = name1),
             map = kormap1, interactive = T)

#############################################################################

korpop2_kp <- korpop2
korpop2_kp <- rename(korpop2_kp, name = 행정구역별_읍면동, pop = 총인구_명)
ggChoropleth(data = korpop2_kp, aes(fill = pop, map_id = code), map = kormap2)
ggChoropleth(data = korpop2_kp, aes(fill = pop, map_id = code, tooltip = name),
             map = kormap2, interactive = T)

korpop3_kp <- korpop3
korpop3_kp <- rename(korpop3_kp, name = 행정구역별_읍면동, pop = 총인구_명)
ggChoropleth(data = korpop3_kp, aes(fill = pop, map_id = code), map = kormap3)
ggChoropleth(data = korpop3_kp, aes(fill = pop, map_id = code, tooltip = name),
             map = kormap3, interactive = T)

#############################################################################

korpop2_kp2 <- korpop2
areacode_kp2 <- korpop2_kp2 %>% 
    select(code, 행정구역별_읍면동) %>% 
    rename(name = 행정구역별_읍면동)
areacode_kp2$code <- as.character(areacode_kp2$code)
korpop2_kp2 <- left_join(korpop2_kp2, changeCode(areacode_kp2), by = 'code')
korpop2_kp2 <- rename(korpop2_kp2, pop = 총인구_명)
ggChoropleth(data = korpop2_kp2, aes(fill = pop, map_id = code), map = kormap2)
ggChoropleth(data = korpop2_kp2, aes(fill = pop, map_id = code, 
                                     tooltip = name),
             map = kormap2, interactive = T)


korpop3_kp2 <- korpop3
areacode_kp3 <- korpop3_kp2 %>% 
    select(code, 행정구역별_읍면동) %>% 
    rename(name = 행정구역별_읍면동)
areacode_kp3$code <- as.character(areacode_kp3$code)
korpop3_kp2 <- left_join(korpop3_kp2, changeCode(areacode_kp3), by = 'code')
korpop3_kp2 <- rename(korpop3_kp2, pop = 총인구_명)
ggChoropleth(data = korpop3_kp2, aes(fill = pop, map_id = code), map = kormap3)
ggChoropleth(data = korpop3_kp2, aes(fill = pop, map_id = code, 
                                     tooltip = name),
             map = kormap3, interactive = T)

#############################################################################

# kormaps2014 패키지는 지역별 결핵 환자수 정보 데이터(tbc)도 제공한다.
head(changeCode(tbc))
# 결핵 환자수(NewPts)를 사용해서 단계 구분도를 작성할 수 있다.
tbc_kp <- tbc
areacode_tbc <- areacode
tbc_kp$code <- as.character(tbc_kp$code)
class(tbc_kp$code) # character
areacode_tbc$code <- as.character(areacode_tbc$code)
class(areacode_tbc$code) # character
tbc_kp <- left_join(tbc_kp, changeCode(areacode_tbc), by = 'code')
ggChoropleth(data = tbc_kp, aes(fill = NewPts, map_id = code, tooltip = name),
             map = kormap1, interactive = T)

#############################################################################

# interactive 그래프
# 마우스 움직임에 반응해 실시간으로 형태가 변하는 그래프
# ggplot2 패키지를 이용해 만든 그래프에 plotly 패키지의 ggplotly() 함수를 적용
# 시키면 된다.
install.packages('plotly')
library(plotly)

ggplot(mpg, aes(displ, hwy, col = drv)) + geom_point()
ggplotly(ggplot(mpg, aes(displ, hwy, col = drv)) + geom_point())

# 차트도 변수에 저장시킬 수 있다.
g <- ggplot(mpg, aes(displ, hwy, col = drv)) + geom_point()
ggplotly(g)

g <- ggplot(diamonds, aes(cut, col = clarity)) + 
    geom_bar(position = 'dodge')
ggplotly(g)

#############################################################################

# interactive 시계열 그래프
# dygraphs 패키지를 사용해 interactive 시계열 그래프를 만들려면 데이터가 시간
# 순서의 속성을 가지고 있는 xts 데이터 타입으로 되어 있어야 하고 xts() 함수를
# 사용해 그래프로 표시하려는 데이터 타입을 변경해서 추출해야 한다.
install.packages('dygraphs')
library(dygraphs)
# dygraphs 패키지가 설치될 때 같이 설치되므로 로드만 하면된다.
library(xts)

str(economics)
# xts(interactive 시계열 그래프로 표시할 데이터, order.by = 시계열 데이터)
eco <- xts(economics$unemploy, order.by = economics$date)
# dygraph() 함수에 xts 데이터 타입의 데이터를 지정해서 그래프를 만든다.
dygraph(eco)
# '%>%'를 이용해서 dyRangeSelector() 함수를 실행하면 그래프 하단에 시계열
# 범위를 변경할 수 있는 기능이 추가된다.
dygraph(eco) %>% dyRangeSelector()

# interactive 시계열 그래프에 여러 값 표시하기
# 실업자수(unemploy)와 저축율(psavert)을 interactive 시계열 그래프로 표시하기
# 위해 각각의 값을 기억하는 변수를 xts() 함수를 이용해 만든다.

# 시계열 그래프로 표시할 데이터의 단위가 일치하지 않으면 맞춰줘야 한다.
eco_unemploy <- xts(economics$unemploy / 1000, order.by = economics$date)
eco_psavert <- xts(economics$psavert, order.by = economics$date)
head(eco_unemploy)
head(eco_psavert)

# 행열 형태의 데이터를 가지는(열이름, 변수명이 없는) 데이터를 합친다.
# cbind() => dplyr 패키지의 left_join() 함수와 같은 기능이 실행된다.
# rbind() => dplyr 패키지의 bind_rows() 함수와 같은 기능이 실행된다.
# cbind() 함수를 사용해 eco_unemploy와 eco_psavert를 합친다.
eco2 <- cbind(eco_unemploy, eco_psavert)
head(eco2)

# colnames() => dplyr 패키지의 rename() 함수와 같은 기능이 실행된다.
colnames(eco2) <- c('unemploy', 'psavert')
head(eco2)

dygraph(eco2) %>% dyRangeSelector()











