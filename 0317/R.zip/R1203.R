# 텍스트 마이닝
# 텍스트 마이닝이란 문자로 된 데이터에서 가치있는 정보를 얻어내서 분석하는
# 기법을 말한다.
# 텍스트 마이닝을 할 때 가장 먼저 하는 작업은 분석하려는 텍스트가 저장된 웹
# 페이지의 텍스트를 얻어오는 것이다. => 크롤링, 스크레이핑
# 준비된 데이터의 문장을 구성하는 어절들이 어떤 품사로 되어있는지 파악하는 
# 형태소 분석 작업을 한다.
# 형태소 분석이란 어절들의 품사를 파악한 후 명사, 형용사, 동사 등 의미를 가진
# 품사의 단어를 추출해 각 단어가 얼마나 등장했는가 파악하는 것이다.

# 1. 자바가 먼저 설치되어 있어야 하고 아래의 패키지를 설치하고 로드한다.
install.packages('rJava')
library(rJava)
install.packages('digest')
library(digest)
install.packages('rlang')
library(rlang)
install.packages('KoNLP')
library(KoNLP)

# 2. 데이터 전처리에 사용할 패키지를 로드하고 사용할 형태소 사전을 설정한다.
library(dplyr)
useNIADic() # 983012 words dictionary was built.

# 3. 형태소 분석 작업을 실행할 데이터를 읽어들인다.
# readLines() 함수로 텍스트 마이닝을 실행할 텍스트 파일을 읽어들인다.
txt <- readLines('hiphop.txt')

# 정규식 => https://highcode.tistory.com/6 참조
# ^ : 문자열의 시작
# $ : 문자열의 종료
# . : 임의의 한 문자 (문자의 종류 가리지 않음) 단, \ 는 넣을 수 없음
# * : 앞 문자가 없을 수도 무한정 많을 수도 있음
# + : 앞 문자가 하나 이상
# ? : 앞 문자가 없거나 하나있음
# [] : 문자의 집합이나 범위를 나타내며 두 문자 사이는 - 기호로 범위를 나타낸다.
#      []내에서 ^가 선행하여 존재하면 not 을 나타낸다.
# {} : 횟수 또는 범위를 나타낸다.
# () : 소괄호 안의 문자를 하나의 문자로 인식 
# | : 패턴 안에서 or 연산을 수행할 때 사용
# \s : 공백 문자
# \S : 공백 문자가 아닌 나머지 문자
# \w : 알파벳이나 숫자
# \W : 알파벳이나 숫자를 제외한 문자
# \d : 숫자 [0-9]와 동일
# \D : 숫자를 제외한 모든 문자
# \ : 정규표현식 역슬래시(\)는 확장 문자
#     역슬래시 다음에 일반 문자가 오면 특수문자로 취급하고 역슬래시 다음에
#     특수문자가 오면 그 문자 자체를 의미
# (?i) : 앞 부분에 (?i) 라는 옵션을 넣어주면 대소문자를 구분하지 않음

# 자주 쓰이는 패턴
# 숫자만 : ^[0-9]*$
# 영문자만 : ^[a-zA-Z]*$
# 한글만 : ^[가-힣]*$
# 영어 & 숫자만 : ^[a-zA-Z0-9]*$
# E-Mail : ^[a-zA-Z0-9]+@[a-zA-Z0-9]+$
# 휴대폰 : ^01(?:0|1|[6-9]) - (?:\d{3}|\d{4}) - \d{4}$
# 일반전화 : ^\d{2,3} - \d{3,4} - \d{4}$
# 주민등록번호 : \d{6} \- [1-4]\d{6}
# IP 주소 : ([0-9]{1,3}) \. ([0-9]{1,3}) \. ([0-9]{1,3}) \. ([0-9]{1,3})

# POSIX 표준 정규 표현식의 문자 클래스
# [:alnum:] : 알파벳과 숫자
# [:alpha:] : 알파벳 대소문자
# [:blank:] : 탭(\t)
# [:cntrl:] : 제어 문자
# [:digit:] : 숫자
# [:xdigit:] : 16진수(hex)형 숫자, 즉 [0-9a-fA-F]
# [:upper:] : 알파벳 대문자
# [:lower:] : 알파벳 소문자
# [:space:] : 탭(\t), CR(\r), LF(\n)
# [:print:] : 출력 가능한 문자
# [:graph:] : 공백을 제외한 문자
# [:punct:] : 출력 가능한 특수 문자
# 정규 표현식에서 POSIX를 사용할 경우 "["와 "]"로 묶어줘야 한다.

# 4. 텍스트 마이닝을 수행할 데이터에서 정규 표현식 또는 gsub() 함수를 사용해서
# 불필요한 문자를 제거한다. => 전처리
# R에서 정규 표현식을 사용하려면 stringr 패키지를 설치하고 로드한다.
install.packages('stringr')
library(stringr)

txt <- readLines('hiphop.txt')
# str_replace_all(변수, '찾을 문자열', '바꿀 문자열')
# '\'는 연속해서 2개를 써야 '\'로 인식된다.
txt <- str_replace_all(txt, '\\W', ' ')
# gsub('찾을 문자열', '바꿀 문자열', 변수)
txt <- gsub('\\W', ' ', txt)
# [:punct:](출력 가능한 특수 문자)를 사용하면 모든 특수 문자가 제거되고 공백은
# 유지된다.
txt <- gsub('[[:punct:]]', '', txt)
# 특수 문자와 숫자까지 제거하려면 아래와 같이 사용한다.
txt <- gsub('[[:punct:][:digit:]]', '', txt)
head(txt)

# 5. extractNoun() 함수를 사용해 명사를 추출한다. => 결과는 list 타입이다.
extractNoun('대한민국의 영토는 한반도와 그 부속 도서로 한다.')
noun <- extractNoun(txt)
class(noun)
# unlist() 함수로 추출된 명사 list를 charactor 벡터로 변환한다.
noun <- unlist(noun)
class(noun)
head(noun, 10)

# 6. table() 함수를 사용해 단어별 빈도표를 만든다.
wordCount <- table(noun)
class(wordCount) # table
head(wordCount, 10)

# table 타입으로 생성된 단어별 빈도표를 as.data.frame() 함수를 사용해 데이터
# 프레임으로 변환한다.
df_wordCount <- as.data.frame(wordCount)
class(df_wordCount) # data.frame
head(df_wordCount, 10)

# 데이터 프레임의 변수 이름을 워드 클라우드 옵션에 맞게 변경한다. 안해도 됨!!!
df_wordCount <- rename(df_wordCount, word = noun, freq = Freq)

# 7. 단어가 숫자로만 구성된 경우 제거한다. => 선택적으로...
# 단어에 포함된 모든 숫자를 제거한다.
df_wordCount$word <- gsub('[[:digit:]]', '', df_wordCount$word)
# 단어가 숫자로만 구성된 경우 제거한다.
df_wordCount$word <- gsub('^[0-9]*$', '', df_wordCount$word)
df_wordCount$word <- gsub('  ', '', df_wordCount$word)

# 8. 단어를 구성하는 음절의 개수가 두 글자 이상으로 구성된 단어만 추출하고 
# 출현 빈도수의 내림차순으로 정렬해서 필요한 개수의 단어를 추출한다.
# nchar() : 글자수를 세는 함수
df_wordCount <- df_wordCount %>% filter(nchar(word) >= 2)

# 워드 클라우드로 구성할 단어를 추출한다.
top200 <- df_wordCount %>% arrange(desc(freq)) %>% head(200)

#############################################################################

# 워드 클라우드
# 단어의 출현 빈도를 구름 모양으로 표현한 그래프로 단어의 출현 빈도에 따라 
# 글자의 크기와 색이 다르게 표현되기 때문에 어떤 단어가 얼마나 많이 사용되었
# 는지 한 눈에 파악할 수 있다.

# 워드 클라우드 패키지를 설치하고 로드한다.
install.packages('wordcloud')
library(wordcloud)
# RColorBrewer 패키지가 자동으로 로딩되지 않을 경우 R에 내장된 패키지이므로 
# 별도의 설치 없이 로드만 하면된다.
library(RColorBrewer)

# brewer.pal() 함수를 사용해 단어에 표시할 색 목록을 만든다. => 선택적으로...
# 색상 팔레트에 대한 자세한 사항은 크롬에서 '팔레트 in r'로 검색하거나 아래의
# url을 참조한다.
# http://www.datamarket.kr/xe/index.php?mid=board_AGDR50&document_srl=203&listStyle=viewer
# brewer.pal(표현할 색상 개수, '팔레트 이름')
pal <- brewer.pal(10, 'Paired')

# 난수 고정하기 => 선택적으로...
# 워드 클라우드는 함수가 실행될 때 마다 난수를 이용해 매번 다른 모양의 워드
# 클라우드를 만들기 때문에 항상 동일한 모양의 워드 클라우드가 생성되기를
# 원한다면 워드 클라우드 함수를 실행하기 전에 set.seed() 함수를 사용해서
# 난수를 고정시킨다.
set.seed(1)

# 워드 클라우드를 만든다.
wordcloud(
    words = top200$word, # 워드 클라우드로 표시할 단어 목록
    freq = top200$freq,  # 워드 클라우드에 표시할 단어의 출현 빈도수
    min.freq = 2,        # 워드 클라우드에 표시할 단어의 최소 개수
    max.words = 200,     # 워드 클라우드에 표시할 단어의 최대 개수
    rot.per = 0.1,       # 워드 클라우드에 표시되는 단어의 회전 빈율
    random.order = F,    # 출현 빈도가 높은 단어를 중앙에 배치한다.
    scale = c(5, 0.5),   # 워드 클라우드에 표시되는 단어의 크기 범위
    colors = pal         # 단어에 표시할 색상 목록이 저장된 팔레트
)

#############################################################################

# 국정원 트윗 데이터 분석하기

# twitter.csv 파일을 읽어온다.
twitter <- read.csv('twitter.csv', fileEncoding = 'UTF-8', header = T,
                    stringsAsFactors = F)
class(twitter) # data.frame
str(twitter)

# 데이터 프레임의 변수 이름을 변경한다.
twitter <- rename(twitter, no = 번호, id = 계정이름, data = 작성일, tw = 내용)

# 특수 문자와 제어 문자를 없앤다.
twitter$tw <- gsub('[[:punct:][:cntrl:]]', '', twitter$tw)

# 트윗 데이터를 형태소 분석한다.
nouns <- extractNoun(twitter$tw)
nouns <- unlist(nouns)

# 단어별 출현 빈도수를 계산하고 데이터 프레임으로 만든다.
wordCount <- table(nouns)
df_wordCount <- as.data.frame(wordCount)
head(df_wordCount, 10)

# 데이터 프레임의 변수 이름을 수정하고 2글자 이상 6글자 이하인 단어만 뽑아낸다.
df_wordCount <- rename(df_wordCount, word = nouns, freq = Freq)
df_wordCount$word <- gsub('^[0-9]*$', '', df_wordCount$word)
df_wordCount$word <- gsub('들이', '', df_wordCount$word)
df_wordCount$word <- gsub('하지', '', df_wordCount$word)
df_wordCount$word <- gsub('북한', '', df_wordCount$word)
df_wordCount <- df_wordCount %>% filter(nchar(word) >= 2 & nchar(word) <= 6)
top200 <- df_wordCount %>% arrange(desc(freq)) %>% head(200)
    
# 워드 클라우드를 만든다.
pal <- brewer.pal(10, 'Dark2')
set.seed(2)
wordcloud(
    words = top200$word, # 워드 클라우드로 표시할 단어 목록
    freq = top200$freq,  # 워드 클라우드에 표시할 단어의 출현 빈도수
    min.freq = 2,        # 워드 클라우드에 표시할 단어의 최소 개수
    max.words = 200,     # 워드 클라우드에 표시할 단어의 최대 개수
    rot.per = 0.2,       # 워드 클라우드에 표시되는 단어의 회전 빈율
    random.order = F,    # 출현 빈도가 높은 단어를 중앙에 배치한다.
    scale = c(4, 0.5),   # 워드 클라우드에 표시되는 단어의 크기 범위
    colors = pal         # 단어에 표시할 색상 목록이 저장된 팔레트
)

#############################################################################

twitter <- read.csv('twitter.csv', fileEncoding = 'UTF-8', header = T,
                    stringsAsFactors = F)
twitter <- rename(twitter, no = 번호, id = 계정이름, data = 작성일, tw = 내용)
twitter$tw <- gsub('[[:punct:][:cntrl:]]', '', twitter$tw)
nouns <- extractNoun(twitter$tw)
nouns <- unlist(nouns)
wordCount <- table(nouns)
df_wordCount <- as.data.frame(wordCount)
df_wordCount <- rename(df_wordCount, word = nouns, freq = Freq)
df_wordCount$word <- gsub('^[0-9]*$', '', df_wordCount$word)
df_wordCount <- df_wordCount %>% filter(nchar(word) >= 2 & nchar(word) <= 6)
top20 <- df_wordCount %>% arrange(desc(freq)) %>% head(20)

library(ggplot2)
order_desc <- arrange(top20, desc(freq))
ggplot(top20, aes(word, freq)) +
    geom_col() +
    coord_flip() +
    scale_x_discrete(limit = order_desc$word) +
    ylim(0, 2500) + 
    geom_text(aes(label = freq), hjust = -0.5) # 차트의 고유 값을 표시한다.

order_asc <- arrange(top20, freq)
ggplot(top20, aes(word, freq)) +
    geom_col() +
    coord_flip() +
    scale_x_discrete(limit = order_asc$word) +
    ylim(0, 2500) + 
    geom_text(aes(label = freq), hjust = -0.5)

#############################################################################

# 단계 구분도
# 단계 구분도는 지역별 통계치를 색깔의 차이로 표현한 지도를 말한다.
# 단계 구분도를 만들려면 지역별 위도, 경도 정보가 저장된 지도 데이터가 필요하기
# 때문에 maps 패키지의 미국 주별 위도, 경도를 저장해 놓은 state 데이터를 사용
# 한다.
install.packages('maps')
library(maps)
# ggplot2 패키지의 map_data() 함수로 지도 데이터를 불러온다.
states_map <- map_data('state')
head(states_map)

# 미국 주별 강력 범죄율(USArrests) 단계 구분도 만들기
# USArrests => 1973년 미국 주별 강력 범죄율 정보
class(USArrests) # data.frame
head(USArrests)
# USArrests 데이터의 행 이름을 tibble 패키지의 rownames_to_column() 함수를 
# 사용해 적당한 이름의 열 이름을 가지는 데이터 프레임으로 만든다.
# tibble 패키지는 dplyr 패키지가 설치될 때 자동으로 설치되는 패키지이므로
# 로드만 하면된다.
library(tibble)

# rownames_to_column() 함수는 행 이름을 var 옵션에서 지정한 변수명으로 데이터화
# 하고 새로 1부터 시작하는 행 이름을 붙여준다.
# rownames_to_column(데이터 프레임, var = '변수이름')
crime <- rownames_to_column(USArrests, var = 'state')

# 지도 데이터의 지역명은 모두 소문자 이므로 때문에 crime의 지역명을 tolower()
# 함수를 사용해서 모두 소문자로 만든다. => toupper()는 모두 대문자로 변환한다.
crime$state <- tolower(crime$state)
head(crime)

# ggiraphExtra 패키지의 ggChoropleth() 함수를 사용해 단계 구분도를 만든다.
install.packages('ggiraphExtra')
library(ggiraphExtra)
install.packages('mapproj')
library(mapproj)

ggChoropleth(
    data = crime,        # 단계 구분도로 표시할 데이터
    aes(fill = Murder,   # 데이터로 사용할 변수
        map_id = state), # 지도 데이터의 지역이 저장된 변수
    map = states_map     # 지도 데이터(위도, 경도 정보)
)
ggChoropleth(data = crime, aes(fill = Assault, map_id = state), 
             map = states_map)
ggChoropleth(data = crime, aes(fill = Rape, map_id = state), 
             map = states_map)







