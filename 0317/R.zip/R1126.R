# array : array() 함수를 사용해서 만든다.
# dim 속성을 이용해서 행, 열, 면 순서로 array 구조를 정의한다.
# dim = c(2, 3, 4) => 2행 3열짜리 matrix가 4개 있다는 의미이다.
arr1 <- array(c(1:24), dim = c(2, 3, 4))

# array의 인덱싱과 슬라이싱
arr1[,,1] # array에서 1번째 면(1번째 matrix)의 데이터를 얻어온다.
arr1[1,,1] # array에서 1번째 면의 1번째 행 데이터를 얻어온다.
arr1[,2,2] # array에서 2번째 면의 2번째 열 데이터를 얻어온다.
arr1[1,,] # array에서 모든 면의 1번째 행 데이터를 얻어온다.
arr1[1,2,] # array에서 모든 면의 1번째 행 2번째 열의 데이터를 얻어온다.

# data frame : data.frame() 함수를 하용해서 만든다.
data1 <- c(1, 2, 3, 4, 1, 2)
class(data1)
data2 <- c('a', 'b', 'c', 'd', 'a', 'b')
class(data2)
# vector를 만들 때 문자와 숫자가 섞여있으면 모두 문자로 취급된다.
data3 <- c(1, 'a', 'b', 'a', 1, 'c')
class(data3)

# data.frame(데이터 프레임으로 만들 벡터들...)
# 데이터 프레임을 만들 때 사용한 벡터의 이름이 데이터 프레임의 열(변수) 
# 이름으로 사용된다.
df1 <- data.frame(data1, data2, data3)
class(df1)

# 데이터 프레임의 특정 열의 값을 얻어오는 방법은 2가지가 있다.
# 1. 데이터프레임이름[열번호] => 데이터 프레임 형태로 데이터를 얻어온다.
# matrix나 array에서 사용했던 인덱싱 또는 슬라이싱 방법을 그대로 사용할 수 
# 있다.
df_fielf1 <- df1[1]
class(df_fielf1) # data.frame
df_fielf2 <- df1[1:2]
class(df_fielf2) # data.frame
df_fielf3 <- df1[c(1, 3)]
class(df_fielf3) # data.frame
# 2. 데이터프레임이름$열이름 => 얻어오는 열에 저장된 데이터가 숫자면 벡터
# 형태로 데이터를 얻어오고 데이터가 문자면 factor 형태로 데이터를 얻어온다.
df_fielf4 <- df1$data1
class(df_fielf4) # numeric => 벡터
df_fielf5 <- df1$data2
class(df_fielf5) # factor
df_fielf6 <- df1$data3
class(df_fielf6) # factor
# 데이터 프레임에 저장되서 factor로 변환된 데이터를 문자 데이터로 사용하려면
# as.character() 함수를 사용해서 문자 데이터로 변환시킨 후 사용하면 된다.
data4 <- as.character(df_fielf5)
class(data4) # character => 벡터

# list : list() 함수를 사용해서 만든다.
v <- 1 # vector
m <- matrix(c(1:12), ncol = 6) # matrix
a <- array(c(1:20), dim = c(2, 5, 2)) # array
d <- data.frame(x1 = c(1, 2, 3), x2 = c('a', 'b', 'c')) # dataframe
list1 <- list(list1 = v, list2 = m, list3 = a, list4 = d)
class(list1) # list

#############################################################################

# 외부 데이터 읽어오기
# read.csv() 함수는 csv 파일(데이터가 ','로 구분된 파일)을 데이터 프레임 형태로
# 읽어온다.
csv_exam <- read.csv('csv_exam.csv')
class(csv_exam)

csv_exam # 데이터 프레임 전체를 얻어온다.
# 데이터 프레임에 []만 붙여 출력하면 csv_exam를 실행한 것과 같다.
csv_exam[]
csv_exam[1,] # 데이터 프레임의 1행만 얻어온다.
csv_exam[1:2,] # 데이터 프레임의 1행 부터 2행까지 얻어온다.
csv_exam[c(1, 3),] # 데이터 프레임의 1행과 3행을 얻어온다.
# ','를 입력하면 데이터 프레임으 행과 열을 구분해서 출력하지만 아래와 같이 
# ','를 입력하지 않으면 무조건 열 단위로 데이터를 얻어온다.
csv_exam[3] # 데이터 프레임의 3번째 열만 얻어온다. => 데이터 프레임
class(csv_exam[3]) # data.frame
csv_exam[,3] # 데이터 프레임의 3번째 열만 얻어온다. => 벡터 또는 factor
class(csv_exam[,3]) # integer
csv_exam$english # 데이터 프레임에서 english 열만 얻어온다. => 벡터 또는 factor
class(csv_exam$english) # integer
# [] 안에 열 이름을 사용하면 이름이 지정된 열 데이터를 얻어올 수 있다.
csv_exam['english']
class(csv_exam['english']) # data.frame
csv_exam[,'english']
class(csv_exam[,'english']) # integer
# c() 함수를 사용하면 데이터 프레임의 여러 열 이름을 이용해 데이터를 얻어올 수
# 있다. => 2개 이상의 열을 얻어오면 데이터 프레임 형태로 얻어온다.
csv_exam[c('english', 'science')]
class(csv_exam[c('english', 'science')]) # data.frame
csv_exam[,c('math', 'science')]
class(csv_exam[,c('math', 'science')]) # data.frame

# 조건에 만족하는 데이터 프레임의 데이터 얻어오기
# 데이터 프레임의 class 열에 저장된 값이 1인 행만 얻어오기
# 지정된 조건에 만족하는 행 단위의 데이터를 얻어와야 하므로 끝에 ','를 반드시
# 찍어야 한다.
csv_exam[csv_exam$class == 1,]
# 데이터 프레임의 math 열에 저장된 데이터가 80 이상인 행만 얻어온다.
csv_exam[csv_exam$math >= 80,]
# 데이터 프레임의 class 열에 저장된 데이터가 1이고 english 열에 저장된 데이터가
# 90 이상인 행만 얻어온다.
csv_exam[csv_exam$class == 1 & csv_exam$english >= 90,] # & => and 연산자
# 데이터 프레임의 math 열에 저장된 데이터가 30 이하이거나 science 열에 저장된
# 데이터가 30 이하인 행만 얻어온다.
csv_exam[csv_exam$math <= 30 | csv_exam$science <= 30,] # | => or 연산자

# 읽어들일 csv 파일의 첫 줄이 열 이름이 아닐 경우 header = FALSE 옵션을 지정
# 해서 읽어들이면 된다. => R이 자동으로 V1, V2, ... 와 같이 열 이름을 자동으로
# 붙여준다. => 읽어들인 후 열 이름을 변경시켜 사용하면 된다.
# R은 TRUE와 FALSE를 모두 대문자로 사용해야 한다. => T와 F로 줄여서 써도된다.
# 문자가 저장된 csv 파일을 읽어들일 때 stringsAsFactors = F 옵션을 지정하지
# 않으면 데이터를 문자가 아닌 factor 타입으로 읽어들여 처리할 때 오류가 발생할
# 수 있다.
csv_exam_noheader <- read.csv('csv_exam_noheader.csv', header = F,
                              stringsAsFactors = F)

# 데이터 프레임의 열 이름을 변경하려면 rename() 함수를 사용한다.
# rename() 함수를 사용하려면 dplyr 패키지를 설치한 후 로드한 다음 사용한다.
install.packages('dplyr')
library(dplyr)

# rename(데이터 프레임 이름, 새 열이름 = 기존 열이름, ...)
csv_exam_noheader <- rename(csv_exam_noheader, id = V1)
csv_exam_noheader <- rename(csv_exam_noheader, class = V2, math = V3,
                            english = V4, science = V5)

# 원본 데이터를 읽었으면 망칠것에 대비해서 사본을 만들어서 작업한다.
csv_exam_copy <- csv_exam_noheader

# excel 파일을 csv 파일로 변환하지 않고 바로 읽어들이려면 readxl 패키지를 설치
# 하고 로드한 후 사용한다.
install.packages('readxl')
library(readxl)

# read_excel() 함수는 excel 파일 tibble 형태로 읽어온다.
excel_exam <- read_excel('excel_exam.xlsx')
class(excel_exam) # tibble
# tibble 타입의 데이터는 사용하는 패키지에 따라서 정상적으로 처리되지 않을 수
# 있기 때문에 데이터 프레임으로 변환시킨 후 사용하는 것이 좋다.
df_excel_exam <- as.data.frame(excel_exam)
class(df_excel_exam) # data.frame

# 읽어들일 excel 파일의 첫 줄이 열 이름이 아닐 경우 col_names = F 옵션을 지정
# 해서 읽어들이면 된다. => 읽어들인 후 열 이름을 변경시켜 사용하면 된다.
# col_names = F 옵션을 사용해서 읽어들인 excel 파일의 열 이름은 R이 자동으로
# ...1, ...2와 같이 열 이름을 붙여준다.
excel_exam_noheader <- read_excel('excel_exam_noheader.xlsx', col_names = F)
# 만약에 R이 자동으로 붙여준 열 이름을 변경할 때 에러가 발생되면 R이 자동으로
# 붙여준 열 이름을 따옴표로 묶어서 실행하면 된다.
excel_exam_noheader <- rename(excel_exam_noheader, id = ...1)
#만약에 위의 식이 에러가 발생된다면 아래와 같이 실행하면 된다.
excel_exam_noheader <- rename(excel_exam_noheader, id = '...1')
excel_exam_noheader <- rename(excel_exam_noheader, class = ...2, math = ...3,
                              english = ...4, science = ...5)

# 읽어들일 excel 파일에 여러개의 sheet가 있을 때 특정 sheet의 데이터를 읽으려면
# sheet = n(n은 읽을 sheet의 위치) 옵션을 지정해서 읽어들인다.
excel_exam_sheet3 <- read_excel('excel_exam.xlsx', sheet = 3)

#############################################################################

# csv 파일로 저장하기
# write.csv() 함수로 데이터 프레임을 csv 파일로 저장할 수 있다.
# write.csv(데이터 프레임, file = '출력할 csv 파일명')
class(excel_exam) # tibble
# tibble 타입의 데이터는 데이터 프레임 타입으로 변환시킨 후 저장한다.
df_excel_exam <- as.data.frame(excel_exam)
class(df_excel_exam) # data.frame
# write.csv() 함수로 출력할 때 df_excel.exam.csv 파일이 열려있으면 파일을 여는
# 데 실패했다는 메시지가 출력되며 에러가 발생되므로 반드시 출력 파일이 닫혀있는
# 상태에서 실행한다.
write.csv(df_excel_exam, file = 'df_excel.exam.csv')

# RData 파일은 R 전용 데이터 파일로 다른 파일에 비해서 R에서 읽고 쓰는 속도가
# 빠르고 용량이 작다는 장점이 있다.
# 일반적으로 R에서 작업할 때는 RData 파일을 사용하고 R을 사용하지 않는 사람과
# 데이터를 주고 받을 경우 csv 파일이나 excel 파일을 사용한다.
# 작업중인 데이터를 R 전용 데이터 파일로 저장하고 필요할 때 불러와서 사용하면
# 된다.

# save() 함수로 데이터 프레임을 RData 파일(*.rda)로 저장한다.
# save(데이터 프레임, file = 'RData 파일명')
save(df_excel_exam, file = 'excel_exam.rda')

# rm() 함수로 사용중인 기억 장소를 메모리에서 제거할 수 있다.
rm(df_excel_exam)

# load() 함수로 RData 파일에 저장된 데이터를 메모리로 가져온다.
# load(file = 'RData 파일명')
load(file = 'excel_exam.rda')
# load() 함수로 불러온 RData 파일은 변수에 할당하면 안된다.
# 아래와 같이 load() 함수 실행 결과를 변수에 할당하면 문자 데이터로 취급된다.
# RData 파일을 생성할 때 입력한 데이터 프레임 이름이 변수에 저장된다.
df_excel_exam_load <- load(file = 'excel_exam.rda') # 이렇게 하면 안된다.
class(df_excel_exam_load) # character

#############################################################################

# summary() 함수를 사용해서 데이터의 요약 통계량을 출력한다.
summary(df_excel_exam)
# str() 함수를 사용해서 데이터 프레임에 저장된 데이터의 개수, 변수(열)의 개수
# 변수 이름, 변수의 자료형, 변수에 저장된 데이터의 일부를 볼 수 있다.
str(df_excel_exam)
