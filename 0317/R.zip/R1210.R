# 트위터 검색하기
install.packages('twitteR')
library(twitteR)

# 트위터 검색을 하기 위한 API key를 설정한다.
api_key <- 'gjUkHgO8bFmNobRk4g0Jas8xb'
api_secret <- 'loF0mtnzLhtQDFjahdRHox6wcR1fiD6Fw95DP5QCSy3rLTTP1K'
access_token <- '607145164-8L5HtzopZzhjuBCgusUGKE3MHOa9P4RbmhUrM0E1'
access_token_secret <- '2wn2bsCA7JIH5DZ5Ss1deS5BNLabzaX2xSpM2ZLMIqwQf'
# 직접 트위터 검색을 위한 API key를 받으려면 아래의 링트를 참조한다.
# https://stat-and-news-by-daragon9.tistory.com/105

# 트위터에 연결한다.
setup_twitter_oauth(api_key, api_secret, access_token, access_token_secret)
# 트위터에 연결될 때 아래 메시지를 출력하고 응답을 기다린다. => 2를 입력한다.
# Use a local file ('.httr-oauth'), to cache OAuth access credentials between R
# sessions?
#
# 1: Yes
# 2: No
#
# 선택: 2를 입력하고 엔터키를 누른다.

# 트위터에서 검색할 검색어를 지정한다.
key <- '개발자'
# 검색어를 유니코드로 변환한다.
key <- enc2utf8(key)

# searchTwitter() 함수로 검색어가 포함된 트위터를 지정한 개수(n) 만큼 검색한다.
# searchTwitter('검색어', n = 최대 검색 개수)
result <- searchTwitter(key, n = 10000)
# searchTwitter() 함수로 검색어가 포함된 트위터를 지정한 개수(n) 만큼 검색한다.
# searchTwitter('검색어', since = '시작 날짜', until = '종료 날짜')
result <- searchTwitter(key, since = '2019-01-01', n = 10000)
# searchTwitter() 함수로 위도와 경도를 지정해서 검색어가 포함된 트위터를 지정한
# 개수(n) 만큼 검색한다.
# searchTwitter('검색어', geocode = '위도,경도,거리km', n = 최대 검색 개수)
# geocode 속성 내부에는 띄어쓰기를 하면 안된다.
result <- searchTwitter(key, geocode = '37.500,127.036,100km', n = 10000)

# twListToDF() 함수로 검색된 트위터 데이터를 데이터 프레임으로 변환한다.
df_twitter <- twListToDF(result)

#############################################################################

library(dplyr)
library(rJava)
library(KoNLP)
library(RColorBrewer)
library(wordcloud)
useNIADic()

# 검색한 트위터 데이터에서 텍스트만 추출한다.
twitter_data <- df_twitter$text
twitter_data <- gsub('[[:punct:][:cntrl:]]', '', twitter_data)
twitter_data <- gsub('[^[:alnum:][:blank:]+?&/\\-]', '', twitter_data)
twitter_data <- gsub('^[ㄱ-ㅎㅏ-ㅣ]*$', '', twitter_data)
twitter_data <- gsub('http.*', '', twitter_data)

nouns <- extractNoun(twitter_data)
nouns <- unlist(nouns)
wordCount <- table(nouns)
df_wordCount <- as.data.frame(wordCount)
df_wordCount <- rename(df_wordCount, word = nouns, freq = Freq)
df_wordCount$word <- gsub('[^[:alnum:][:blank:]+?&/\\-]', '', df_wordCount$word)
df_wordCount$word <- gsub('^[ㄱ-ㅎㅏ-ㅣ]*$', '', df_wordCount$word)
df_wordCount$word <- gsub('RT', '', df_wordCount$word)
df_wordCount$word <- gsub('개발자', '', df_wordCount$word)

wordcloud_data <- df_wordCount %>% 
    filter(nchar(word) >= 2 & nchar(word) <= 6 & freq > 1) %>% 
    arrange(desc(freq)) %>% 
    head(300)
wordcloud_data$word

set.seed(1)
pal <- brewer.pal(8, 'Dark2')
wordcloud(words = wordcloud_data$word,
          freq = wordcloud_data$freq,
          min.freq = 2,
          max.words = 300,
          random.order = F,
          rot.per = 0.2,
          scale = c(3, 0.2),
          colors = pal
)


