# 파생(계산에 의한) 변수 만들기

df_raw <- data.frame(var1 = c(1, 2, 1), var2 = c(2, 3, 4)) # 원본 데이터
# 사본 데이터를 만들어서 작업한다.
df_var <- df_raw

# 1. 데이터프레임$파생변수이름 <- 파생 변수에 대입할 데이터
df_var$var_sum <- df_var$var1 + df_var$var2
df_var$var_mean <- (df_var$var1 + df_var$var2) / 2
df_var$var_mean <- df_var$var_sum / 2

df_excel_exam_copy <- df_excel_exam
df_excel_exam_copy$var_sum <- df_excel_exam_copy$math + 
    df_excel_exam_copy$english + df_excel_exam_copy$science
df_excel_exam_copy$var_mean <- df_excel_exam_copy$var_sum / 3

# subset() 함수로 데이터 프레임에서 특정 변수(열)의 데이터만 뽑아낼 수 있다.
# subset(데이터 프레임, select = 시작변수이름:끝변수이름) # 붙어 있는 변수
df_excel_exam_copy[,c('math', 'english', 'science')]
subset(df_excel_exam_copy, select = math:science)
# subset(데이터 프레임, select = c(변수이름, 변수이름)) # 떨어져 있는 변수
df_excel_exam_copy[,c('math', 'science')]
subset(df_excel_exam_copy, select = c('math', 'science'))

# rowSums() 함수로 행의 합계를 계산할 수 있고 rowMeans() 함수로 행의 평균을
# 계산할 수 있다.
df_excel_exam_copy$var_sum2 <- 
    rowSums(subset(df_excel_exam_copy, select = math:science))
df_excel_exam_copy$var_mean2 <- 
    rowMeans(subset(df_excel_exam_copy, select = math:science))

# 2. transform() 함수를 사용해서 파생 변수를 추가할 수 있다.
# transform(데이터 프레임, 파생 변수 이름 = 파생 변수에 대입할 데이터)
df_excel_exam_copy <- transform(df_excel_exam_copy, 
    var_sum3 = rowSums(subset(df_excel_exam_copy, select = math:science)))
df_excel_exam_copy <- transform(df_excel_exam_copy, 
    var_mean3 = rowMeans(subset(df_excel_exam_copy, select = math:science)))

# 3. dplyr 패키지의 mutate() 함수를 사용해서 한 번에 여러개의 파생 변수를 추가
# 할 수 있다.
df_excel_exam_copy <- df_excel_exam
library(dplyr)

# %>% => dplyr 패키지에서 사용하는 일종의 대입문으로 %>% 왼쪽의 데이터가 %>%
# 오른쪽의 함수로 입력된다.(자바의 '.'와 같은 역할을 한다.) => 파이프
# dplyr 패키지가 메모리에 로드되면 ctrl + shift + M을 동시에 누르면 %>%가 자동
# 으로 입력된다.
# %>% 왼쪽의 데이터 프레임이 %>% 오른쪽의 함수로 전달되기 때문에 데이터
# 프레임의 특정 열을 사용할 때 [데이터프레임이름$변수이름]과 같이 사용하지 
# 않고 데이터 프레임 이름 없이 변수명만 사용하면 된다.
# 함수에서 만든 파생 변수를 함수가 종료되기 전에 사용할 수 있다.
df_excel_exam_copy <- df_excel_exam_copy %>% 
    mutate(
        var_sum = rowSums(subset(df_excel_exam_copy, select = math:science)),
        var_mean = rowMeans(subset(df_excel_exam_copy, select = math:science)),
        var_mean2 = var_sum / 3
    )

# 4. ifelse() 함수로 조건을 지정해서 파생 변수 만들기
# ifelse(조건식, 조건이 참일 때 실행할 내용, 조건이 거짓일 때 실행할 내용)

# 평균 점수(var_mean)가 60 이상이면 'pass' 그렇치 않으면 'fail'을 가지는 
# result 파생 변수를 추가한다.
df_excel_exam_copy$result <- ifelse(df_excel_exam_copy$var_mean >= 60,
                                    'pass', 'fail')
pass <- df_excel_exam_copy[df_excel_exam_copy$result == 'pass',]
fail <- df_excel_exam_copy[df_excel_exam_copy$result == 'fail',]

# 평균 점수가 80 이상이면 'A', 80 미만이고 60 이상이면 'B', 60 미만이면 'C'를
# 가지는 grade 파생 변수를 추가한다.
df_excel_exam_copy$grade <- ifelse(df_excel_exam_copy$var_mean >= 80,
        'A', ifelse(df_excel_exam_copy$var_mean >= 60, 'B', 'C'))

head(df_excel_exam_copy)
tail(df_excel_exam_copy)
df_excel_exam_copy[,c('var_mean', 'result')]

#############################################################################

# hist() 함수로 히스토그램(돗수분포표)를 출력할 수 있다.
hist(df_excel_exam_copy$var_sum) # 숫자 데이터는 가능
hist(df_excel_exam_copy$grade) # 에러, 히스토그램은 숫자만 가능하다.

# table() 함수를 사용해서 변수에 저장되 데이터의 빈도수를 얻어온다.
table(df_excel_exam_copy$var_sum)
table(df_excel_exam_copy$result)
table(df_excel_exam_copy$grade)

library(ggplot2)
qplot(df_excel_exam_copy$var_sum)
qplot(df_excel_exam_copy$result)
qplot(df_excel_exam_copy$grade)

#############################################################################

# 데이터 전처리
# 데이터 전처리는 데이터 분석 작업에 적합하게 데이터를 가공하는 작업이다.
# dplyr 패키지의 함수를 이용해서 데이터의 일부를 추출하거나 종류별로 나누거나
# 여러 데이터를 합치는 등의 작업을 한다.
library(dplyr)

# dplyr 패키지의 주요 함수
# filter() => 행 단위 데이터 추출
# select() => 열 단위 데이터 추출
# arrange() => 정렬
# mutate() => 파생 변수 추가
# summarise() => 통계치 산출
# group_by() => 그룹화
# left_join() => 열 단위 데이터 합치기
# bind_rows() => 행 단위 데이터 합치기

df_excel_exam_dplyr <- df_excel_exam

# filter() 함수로 조건에 만족하는 행 단위 데이터 추출하기
# %>%는 dplyr 패키지에서 사용하는 파이프 연산자로 함수의 실행 결과를 다른 함수
# 의 입력 데이터로 넘겨주는 연산자이다.

# dplyr의 filter() 함수를 사용하지 않고 데이터 프레임에서 조건에 만족하는 행에
# 해당되는 데이터만 추출하는 방법
df_excel_exam_dplyr[df_excel_exam_dplyr$class == 2,]
df_excel_exam_dplyr[df_excel_exam_dplyr$class == 2 | 
                        df_excel_exam_dplyr$class == 5,]

df_excel_exam_dplyr %>% filter(df_excel_exam_dplyr$class == 2)
# 데이터 프레임이 %>% 연산자를 통해 함수로 넘어오기 때문에 특정 변수를 선택할
# 때 데이터 프레임 이름을 적지 않아도 된다.
df_excel_exam_dplyr %>% filter(class == 2)
df_excel_exam_dplyr %>% filter(class == 1 | class == 3)
df_excel_exam_dplyr %>% filter(class == 1 | class == 3 | class == 5)

# %in% => 매칭 연산자, c() 함수와 같이 사용하면 or 연산을 더 쉽게 할 수 있다.
df_excel_exam_dplyr %>% filter(class %in% c(1, 3, 5))

# 함수의 실행 결과를 변수에 저장할 수 있다.
class1 <- df_excel_exam_dplyr %>% filter(class == 1)
class2 <- df_excel_exam_dplyr %>% filter(class == 2)
class3 <- df_excel_exam_dplyr %>% filter(class == 3)
class4 <- df_excel_exam_dplyr %>% filter(class == 4)
class5 <- df_excel_exam_dplyr %>% filter(class == 5)

# mpg 데이터에서 제조사(manufacturer)가 audi와 hyundai 중에서 어떤 제조사의
# 도시 주행 연비(cty) 평균이 더 높은가?
mpg_audi <- mpg %>% filter(manufacturer == 'audi')
mean(mpg_audi$cty) # 17.61111
mpg_hyundai <- mpg %>% filter(manufacturer == 'hyundai')
mean(mpg_hyundai$cty) # 18.64286

# 제조사가 chevrolet, ford, honda인 자동차의 고속도로 주행 연비(hwy)의 전체
# 평균은?
mpg_manufacturer <- mpg %>% 
    filter(manufacturer %in% c('chevrolet', 'ford', 'honda'))
table(mpg_manufacturer$manufacturer)
mean(mpg_manufacturer$hwy) # 22.50943

# select() 함수로 열(변수) 단위 데이터 추출하기
df_excel_exam_dplyr %>% select(math, english, science)
# select() 함수의 인수로 지정하는 변수 이름 앞에 '-'를 붙여주면 '-'를 붙여준
# 변수가 제외된 나머지 변수의 데이터만 추출한다.
df_excel_exam_dplyr %>% select(-math, -science)

# class가 1인 데이터의 math만 출력한다.
df_excel_exam_dplyr %>% filter(class == 1) %>% select(class, math)
df_excel_exam_dplyr %>% select(class, math) %>% filter(class == 1)

# class가 1, 3, 5인 데이터의 science만 추출한다.
# head() 함수와 tail() 함수를 사용해 데이터 프레임의 앞, 뒤에서 필요한 만큼
# 데이터를 출력할 수 있다. => 괄호 안의 인수를 생략하면 6이 기본값이다.
df_excel_exam_dplyr %>% 
    filter(class %in% c(1, 3, 5)) %>% 
    select(class, science) %>% 
    tail(4)

# arrange() 함수를 사용해서 데이터를 정렬시켜 얻어올 수 있다.
df_excel_exam_dplyr %>% arrange(math) # 오름차순 정렬
# desc() 함수와 같이 사용하면 데이터를 내림차순으로 정렬시킬 수 있다.
df_excel_exam_dplyr %>% arrange(desc(math)) # 내림차순 정렬

# math의 내림차순 정렬, math가 같으면 english로 오름차순 정렬
df_excel_exam_dplyr %>% arrange(desc(math), english)
# math의 내림차순 정렬, math가 같으면 english로 오름차순 정렬, english도 같으면
# science의 오름차순 정렬
df_excel_exam_dplyr %>% arrange(desc(math), english, science)

# math 상위 5건의 데이터를 얻어온다.
df_excel_exam_dplyr %>% arrange(desc(math)) %>% head(5)
# math 하위 5건의 데이터를 얻어온다.
df_excel_exam_dplyr %>% arrange(math) %>% head(5)

# mpg에서 제조사가 audi이고 고속도로 주행 연비가 1~5위에 해당되는 데이터를 
# 추출한다.
mpg %>% 
    filter(manufacturer == 'audi') %>% 
    arrange(desc(hwy)) %>% 
    head(5)

# mutate() 함수로 파생 변수를 추가할 수 있다.
df_excel_exam_dplyr %>% mutate(total = math + english + science)
df_excel_exam_dplyr %>% mutate(mean = (math + english + science) / 3)

# 한 번에 여러개의 파생 변수를 추가할 수 있다.
df_excel_exam_dplyr %>% mutate(total = math + english + science,
                               mean = (math + english + science) / 3)
df_excel_exam_dplyr %>% 
    mutate(
        total = rowSums(subset(df_excel_exam_dplyr, select = math:science)),
        mean = rowMeans(subset(df_excel_exam_dplyr, select = math:science))
    )

# 생성한 파생 변수를 바로 사용할 수 있다.
df_excel_exam_dplyr %>% mutate(total = math + english + science,
                               mean = total / 3)

# mpg에서 cty와 hwy를 더한 합산 연비 변수를 만들고 합산 연비 변수의 평균 연비
# 변수를 만든 다음에 평균 연비 변수의 값이 가장 큰 자동차 3건을 추출한다.
mpg %>% 
    mutate(total = cty + hwy, mean = total /2) %>% 
    select(manufacturer, model, mean) %>% 
    arrange(desc(mean)) %>% 
    head(3)

# summarise() 함수와 group_by() 함수를 사용해서 그룹별로 요약하기
df_excel_exam_dplyr %>% mutate(mean_math = mean(math)) %>% head()
df_excel_exam_dplyr %>% summarise(mean_math = mean(math)) %>% head()

# 위의 두 식의 실행 결과를 살펴보면 mutate() 함수는 mean_math라는 파생 변수를
# 만들고 모든 math 데이터의 평균을 계산해 mean_math에 넣어주지만 summarise()
# 함수는 모든 math 데이터의 평균만 계산한다.
# 함수만 실행하면 전체 데이터를 작업 대상으로 하기 때문에 그룹별로 작업을 하기 
# 위해서 group_by() 함수를 사용한다.

# 데이터를 그룹으로 묶에 요약할 때 반드시 group_by() 함수로 먼저 그룹으로
# 묶어주고 summarise() 함수를 사용해서 요약해야 한다.
df_excel_exam_dplyr %>% 
    group_by(class) %>% 
    summarise(mean_math = mean(math))
