# 네이버 웹툰 댓글 워드 클라우드
library(dplyr)
library(rJava)
library(memoise)
library(KoNLP)
useNIADic()

# 워드 클라우드로 작성할 크롤링 데이터가 저장된 csv 파일을 stringsAsFactors = F
# 옵션을 지정해서 벡터 형태로 읽어온다.
movie_review <- read.csv('webtoonReview.csv', stringsAsFactors = F)
class(movie_review$x) # character
# 워드 클라우드에 사용할 데이터만 별도로 저장한다.
review <- movie_review$x

# 특수 문자를 제거한 후 텍스트 마이닝을 실행해서 명사를 추출한다.
txt <- gsub('[[:punct:][:cntrl:]]', '', review)
nouns <- extractNoun(txt)
nouns <- unlist(nouns)

# 단어별 빈도표를 만들고 데이터 프레임으로 변환한다.
wordCount <- table(nouns)
class(wordCount) # table
df_wordCount <- as.data.frame(wordCount)
class(df_wordCount) # data.frame
str(df_wordCount)
df_wordCount <- rename(df_wordCount, word = nouns, freq = Freq)
class(df_wordCount$word) # factor
df_wordCount$word <- as.character(df_wordCount$word)
class(df_wordCount$word) # character

# 불필요한 단어를 제거한다. => 정제
df_wordCount <- df_wordCount %>% 
    filter(nchar(word) >= 2 & nchar(word) <= 6 & freq > 1)
df_wordCount$word <- gsub('^[0-9]*$', '', df_wordCount$word)
# ^ㅋ, ^ㅎ과 같이 한글 자음 앞에 붙어있는 '^'제거
df_wordCount$word <- 
    gsub('[^[:alnum:][:blank:]+?&/\\-]', '', df_wordCount$word)
df_wordCount$word <- gsub('*[\\^]*', '', df_wordCount$word)
df_wordCount$word <- gsub('^[ㄱ-ㅎㅏ-ㅣ]*$', '', df_wordCount$word)

df_wordCount1 <- df_wordCount

# 같은 의미를 가지는 단어는 하나로 통일시킨다.
df_wordCount1$word <- gsub('켈헬람.*', '켈헬람', df_wordCount1$word)
df_wordCount1$word <- gsub('쿤가문.*', '쿤가문', df_wordCount1$word)
df_wordCount1$word <- gsub('하츠.*', '하츠', df_wordCount1$word)
df_wordCount1 <- df_wordCount1 %>% 
    group_by(word) %>% 
    summarise(freq = sum(freq))

# 출현 빈도수 상위 단어 200개를 뽑아낸다.
top200 <- df_wordCount1 %>% 
    arrange(desc(freq)) %>% 
    head(200)

# 출현 빈도수 상위 단어 200개의 워드 클라우드를 만든다.
library(wordcloud)
library(RColorBrewer)
set.seed(1)
pal <- brewer.pal(8, 'Dark2')
wordcloud(words = top200$word,
          freq = top200$freq,
          min.freq = 2,
          max.words = 200,
          rot.per = 0.1,
          random.order = F,
          scale = c(10, 0.2),
          colors = pal
)

library(ggplot2)
# 출현 빈도수 상위 단어 20개의 그래프를 클라우드를 만든다.
top20 <- df_wordCount1 %>% 
    arrange(desc(freq)) %>% 
    head(20)

order_asc <- arrange(top20, freq)$word
order_desc <- arrange(top20, desc(freq))$word
ggplot(top20, aes(word, freq)) +
    geom_col() +
    coord_flip() +
    ylim(0, 400) +
    geom_text(aes(label = freq), hjust = -0.5) +
    scale_x_discrete(limits = order_asc)

#############################################################################

# yes24 명견만리 새로운 사회편 리뷰 스크레이핑
library(RSelenium)
# selenium의 bin 폴더에서 cmd 창을 실행하고 selenium 서버를 기동시킨다.
# java -jar selenium-server-standalone.jar -port 4445
# R에서 selenium 서버를 시작한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
# chrome을 실행한다.
remDr$open()
# yes24 명견만리 새로운 사회편 리뷰 페이지에 접속한다.
remDr$navigate('http://www.yes24.com/Product/Goods/40936880')

#############################################################################

# 스크롤 바를 아래로 이동시켜야 아래쪽의 컨텐츠가 로딩되는 무한 스크롤 방식의
# 페이지를 웹 스크레이핑 하려면 스크롤 바를 한번에 끝까지 내려서는 안되고
# 조금씩 아래로 스크롤 시켜 가면서 웹 페이지가 로딩되는 상황을 봐야한다.

# 웹 페이지의 body 태그(브라우저에 컨텥츠가 표시되는 전체 영역)를 얻어온다.
webBody <- remDr$findElement('css selector', 'body')
# 스크롤 바를 이동시키려면 executeScript() 함수로 javascript를 실행해야 한다.

# 스크롤 바를 끝까지 한꺼번에 내린다. => scrollTo
remDr$executeScript('scrollTo(0, document.body.scrollHeight)', 
                    args = list(webBody))

# 스크롤 바를 조금씩 내린다. => scrollBy
remDr$executeScript('scrollBy(0, 2000)', args = list(webBody))

# 무한 스크롤 방식으로 처리되는 사이트는 스크롤 바가 이동할 때 화면에 보이지
# 않던 컨텐츠가 로딩되므로 컨텐츠가 로딩될 시간을 줘야한다.
Sys.sleep(1)

#############################################################################

# 첫 번째 리뷰의 제목만 읽어온다.
# using 옵션을 생략해도 선택자로 인식한다.
doms <- remDr$findElements(using = 'css selector', 
                           '#infoset_reviewContentList > div:nth-child(3) > div.reviewInfoTop > span.review_tit > span')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
review

# 첫 번째 리뷰의 내용만 읽어온다. => 첫 번째 리뷰 전체 내용을 읽지 못한다.
doms <- remDr$findElements(using = 'css selector', 
                           '#infoset_reviewContentList > div:nth-child(3) > div.reviewInfoBot.crop > div')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
review

# 첫 번째 리뷰의 내용만 읽어온다. => 첫 번째 리뷰 전체 내용을 읽는다.
reviewOpen <- remDr$findElements(using = 'css selector', 
                           '#infoset_reviewContentList > div:nth-child(3) > div.btn_halfMore > a > em.txt.txt_open')
sapply(reviewOpen, function(x) { x$clickElement() })
Sys.sleep(1)
# 펼쳐보기가 클릭되면 표시되는 전체 리뷰 읽기
doms <- remDr$findElements(using = 'css selector', 
                           '#infoset_reviewContentList > div.reviewInfoGrp.infoMoreSubOn > div.reviewInfoBot.origin > div.review_cont')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
review

#############################################################################

# yes24 명견만리 새로운 사회편 전체 리뷰를 읽는다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('http://www.yes24.com/Product/Goods/40936880')

review <- NULL
# 1 페이지의 리뷰를 읽는다.
# 펼쳐보기의 css selector는 모두 똑같고 div:nth-child의 ()안의 숫자만 다르다
for(i in 3:7) {
    # 펼쳐보기 링크를 만든다.
    openLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.btn_halfMore > a > em.txt.txt_open', sep = '')
    # print(openLink)
    # 펼쳐보기 링크를 얻어온다.
    reviewOpen <- remDr$findElements('css selector', openLink)
    # 리뷰가 존재하지 않으면 펼쳐보기 링크도 존재하지 않기 때문에 반복을
    # 중지한다.
    if(length(reviewOpen) == 0) {
        break
    }
    # 펼쳐보기 링크를 클릭한다.
    sapply(reviewOpen, function(x) { x$clickElement() })
    # 펼쳐보기 링크를 클릭했으면 리뷰가 로딩될 때 까지 기다린다.
    Sys.sleep(1)
    # 펼쳐진 리뷰를 읽는다.
    reviewLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.reviewInfoBot.origin > div.review_cont', sep = '')
    doms <- remDr$findElements('css selector', reviewLink)
    result <- sapply(doms, function(x) { x$getElementText() })
    # 읽은 각각의 리뷰를 하나로 합쳐준다.
    review <- c(review, unlist(result))
    Sys.sleep(1)
}
# print(review)

# 리뷰가 끝날 때 까지 무한 루프를 돌면서 나머지 리뷰를 읽는다.
repeat {
    # 첫 페이지의 리뷰를 읽었으므로 2 페이지 부터 10 페이지의 리뷰를 읽는다.
    for(i in 4:12) {
        # 다음 리뷰 페이지 링크를 클릭한다.
        nextLink <- paste('#infoset_reviewContentList > div.review_sort.sortBot > div.review_sortLft > div > a:nth-child(', i, ')', sep = '')
        nextPage <- remDr$findElements('css selector', nextLink)
        if(length(nextPage) == 0) {
            break
        }
        sapply(nextPage, function(x) { x$clickElement() })
        Sys.sleep(1)
        
        # 한 페이지에 보이는 리뷰의 개수(5개) 만큼 반복하며 리뷰를 읽는다.
        for(j in 3:7) {
            openLink <- paste('#infoset_reviewContentList > div:nth-child(', j, ') > div.btn_halfMore > a > em.txt.txt_open', sep = '')
            reviewOpen <- remDr$findElements('css selector', openLink)
            if(length(reviewOpen) == 0) {
                break
            }
            sapply(reviewOpen, function(x) { x$clickElement() })
            Sys.sleep(1)
            reviewLink <- paste('#infoset_reviewContentList > div:nth-child(', j, ') > div.reviewInfoBot.origin > div.review_cont', sep = '')
            doms <- remDr$findElements('css selector', reviewLink)
            result <- sapply(doms, function(x) { x$getElementText() })
            review <- c(review, unlist(result))
            Sys.sleep(1)
        }
    }
    
    # 다음 10 페이지 링크를 클릭해 다음 10 페이지로 넘겨준다.
    next10Page <- remDr$findElements('css selector', '#infoset_reviewContentList > div.review_sort.sortBot > div.review_sortLft > div > a.bgYUI.next')
    # 더 이상 읽을 다음 10 페이지가 없으면 무한 루프를 종료한다.
    if(length(next10Page) == 0) {
        break
    }
    sapply(next10Page, function(x) { x$clickElement() })
    Sys.sleep(1)
    
    # 다음 10 페이지로 넘어왔으므로 다시 첫 페이지를 읽는다.
    for(i in 3:7) {
        openLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.btn_halfMore > a > em.txt.txt_open', sep = '')
        reviewOpen <- remDr$findElements('css selector', openLink)
        if(length(reviewOpen) == 0) {
            break
        }
        sapply(reviewOpen, function(x) { x$clickElement() })
        Sys.sleep(1)
        reviewLink <- paste('#infoset_reviewContentList > div:nth-child(', i, ') > div.reviewInfoBot.origin > div.review_cont', sep = '')
        doms <- remDr$findElements('css selector', reviewLink)
        result <- sapply(doms, function(x) { x$getElementText() })
        review <- c(review, unlist(result))
        Sys.sleep(1)
    }
}
review



