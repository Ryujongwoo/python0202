# 웹 브라우저 원격 조작에 사용하는 Selenium 사용하기
# javascript 컨텐츠를 사용하는 웹 사이트의 경우 url만 안다고 해서 스크레이핑을
# 할 수 없다. => 동적 웹 사이트 => 동적 웹 스크레이핑
# Selenium을 사용하여 url을 자동으로 랜더링해 놓고 랜더링된 결과에서 컨텐츠를
# 읽어와야 한다. 그 뿐만 아니라 컨텐츠 내에서 클릭 이벤트를 발생 시킬 수 있으며
# 데이터를 입력하는 것도 가능하다.

# Selenium 서버 기동 과정
# 1. 임의의 폴더에 chromedriver.exe와 selenium-server-standalone-master.zip를
# 복하한 후 selenium-server-standalone-master.zip의 압축을 해제한다.
# 2. selenium-server-standalone-master.zip의 압축을 해제한 후 bin 폴더에
# chromedriver.exe 파일을 복사해 넣는다.
# 3. cmd 창을 띄워서 chromedriver.exe 파일을 복사해 넣은 bin 폴더로 이동한다.
# 윈도우 탐색기에서 bin 폴더로 이동한 후 아무것도 선택하지 않은 상태에서 shift
# 키와 마우스 오른쪽 버튼을 동시에 누르고 [여기서 명령창 열기] 메뉴를 클릭하면
# 편하게 띄울 수 있다. => windows10은 지원되지 않는다.
# 윈도우 탐색기에서 bin 폴더로 이동한 후 경로 창에다 cmd를 입력하면 된다.
# 4. cmd창의 프롬프트에 java -jar selenium-server-standalone.jar -port 4445를
# 입력해서 Selenium 서버를 기동시킨다. => 서버 기동 후 cmd 창을 닫으면 서버가
# 종료되기 때문에 작업이 완전히 완료되기 전 까지는 cmd 창을 닫으면 안된다.
# cmd 창에 Selenium Server is up and running 메시지가 보이면 Selenium 서버가
# 정상적으로 실행된 상태를 의미한다.

# R에서 Selenium을 사용하기 위한 패키지를 설치하고 로드한다.
install.packages('RSelenium')
library(RSelenium)
# 만약에 install.packages('RSelenium')가 실행되지 않으면 아래와 같이 설치한다.
# devtools 패키지의 install_version() 함수를 사용해 직접 RSelenium을 설치한다.
# install.packages("devtools")
# library(devtools)
# install_version("binman", version = "0.1.0", 
#                 repos = "https://cran.uni-muenster.de/")
# install_version("wdman", version = "0.2.2", 
#                 repos = "https://cran.uni-muenster.de/")
# install_version("RSelenium", version = "1.7.1", 
#                 repos = "https://cran.uni-muenster.de/")
# library(RSelenium)

# R에서 Selenium을 실행한 후 크롬을 실행한다.
# R에서 Selenium 서버에 연결하고 사용할 웹 브라우저를 지정한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
# 지정한 웹 브라우저를 실행한다.
remDr$open()
# 실행된 웹 브라우저에 표시할 웹 페이지 주소를 지정한다.
remDr$navigate('https://www.google.com')
# 웹 페이지에 데이터 입력하고 키 입력하기
webElem <- remDr$findElement(using = 'css', '[name = "q"]')
webElem$sendKeysToElement(list("JAVA", key = 'enter'))

#############################################################################

# 호텔스컴바인에서 이태원 호텔 리뷰 동적 스크레이핑
# Selenium을 실행한 후 크롬을 실행하고 스크레이핑 할 웹 사이트를 연다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://www.hotelscombined.co.kr/Hotel/Search?fileName=I_T_W_Hotel_Itaewon&destination=place:Itaewon&radius=0km&checkin=2019-12-15&checkout=2019-12-16&Rooms=1&adults_1=2&returnPath=%2FHotels%2FSearch%3Fdestination%3Dplace%3AItaewon%26radius%3D0km%26checkin%3D2019-12-15%26checkout%3D2019-12-16%26Rooms%3D1%26adults_1%3D2%26pageSize%3D15%26pageIndex%3D0%26sort%3DPopularity-desc%26showSoldOut%3Dfalse%26scroll%3D1600%26HotelID%3D%26mapState%3Dexpanded%253D0')

# 리뷰 내용
# findElements() 함수에 using 속성으로 css 선택자를 사용해서 웹 스크레이핑을
# 하겠다고 지정하고 2번째 인수 읽어올 데이터가 포함된 css 선택자를 지정한다.
# hc-customerreviews__comments => div 태그의 hc-customerreviews__comments 
# 클래스를 의미한다.
# 다른 곳에도 태그에 hc-customerreviews__comments 클래스가 존재한다면 다른
# 곳의 데이터도 읽어오는 문제가 발생되기 때문에 css 선택자가 포함된 상위 
# 태그의 id를 선택자 앞에 붙여서 자손 선택자로 만들어 사용하면 제대로된
# 스크레이핑을 할 수 있다.
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__comments')
# sapply() 함수로 스크레이핑 한 데이터에서 getElementText() 함수를 실행새서
# 문자열만 얻어온다.
review <- sapply(doms, function(x) { x$getElementText() })
# getElementText() 함수로 읽어들인 문자열의 데이터 타입이 list 타입이므로
# unlist() 함수를 실행해서 벡터로 변환한다.
review <- unlist(review)

# 평점
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headerrate')
point <- sapply(doms, function(x) { x$getElementText() })
point <- unlist(point)

# 리뷰 제목
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headertext')
title <- sapply(doms, function(x) { x$getElementText() })
title <- unlist(title)

Hotel_Itaewon <- cbind(title, point)
Hotel_Itaewon <- cbind(Hotel_Itaewon, review)
Hotel_Itaewon <- as.data.frame(Hotel_Itaewon)
class(Hotel_Itaewon)

#############################################################################

# 호텔스컴바인에서 나트랑 쉐라튼 호텔 리뷰 스크레이핑

remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://www.hotelscombined.co.kr/Hotel/Search?fileName=Sheraton_Nha_Trang&destination=place:Nha_Trang_City_Centre&radius=0km&checkin=2019-12-15&checkout=2019-12-16&Rooms=1&adults_1=2&returnPath=%2FHotels%2FSearch%3Fdestination%3Dplace%3ANha_Trang_City_Centre%26radius%3D0km%26checkin%3D2019-12-15%26checkout%3D2019-12-16%26Rooms%3D1%26adults_1%3D2%26pageSize%3D15%26pageIndex%3D0%26sort%3DPopularity-desc%26showSoldOut%3Dfalse%26scroll%3D1900%26HotelID%3D%26mapState%3Dexpanded%253D0')

# 리뷰 제목
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headertext')
title <- sapply(doms, function(x) { x$getElementText() })
title <- unlist(title)

# 평점
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__headerrate')
point <- sapply(doms, function(x) { x$getElementText() })
point <- unlist(point)

# 리뷰 내용
doms <- remDr$findElements(using = 'css selector', 
                           '#hc_r_3b div.hc-customerreviews__comments')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

Sheraton_NhaTrang <- cbind(title, point)
Sheraton_NhaTrang <- cbind(Sheraton_NhaTrang, review)
Sheraton_NhaTrang <- as.data.frame(Sheraton_NhaTrang)
class(Sheraton_NhaTrang)

#############################################################################

# 아고다에서 나트랑 스완도르 리조트 리뷰 스크레이핑

remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://www.agoda.com/ko-kr/swandor-cam-ranh-hotels-resorts/hotel/nha-trang-vn.html?checkin=2019-12-15&los=1&adults=2&rooms=1&cid=1829971&tag=747e9723-83df-6f99-853a-8505c70753f7&searchrequestid=129ba8ef-fa7d-4dfb-8434-6d383041f386&travellerType=1&tabbed=true')

doms <- remDr$findElements(using = 'css selector', 
                           '#reviewSectionComments p.Review-comment-bodyText')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

#############################################################################

# 네이버 웹툰 베댓 스크레이핑
# 네이버 웹툰의 댓글은 링크 방식으로 처리되지 않고 ajax로 처리된다.
# ajax로 처리되는 사이트는 type이 xhr이고 하이퍼 링크를 클릭했을 때 url이
# 변경되지 않는 특징이 있다.

# https://comic.naver.com/webtoon/detail.nhn  => 웹툰을 보여주는 페이지
# https://comic.naver.com/comment/comment.nhn => 댓글을 보여주는 페이지

# 댓글은 https://comic.naver.com/comment/comment.nhn 페이지의 내용을 ajax로
# 읽어서 id 속성이 commentIframe인 iframe에 넣어준다.
# iframe의 src 속성에 /comment/comment.nhn?titleId=183559&no=458와 같이 댓글을
# 표시하는 페이지의 주소가 지정된다.

# Selenium 서버를 실행한 후 크롬을 실행하고 읽어올 댓글 페이지로 이동한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://comic.naver.com/comment/comment.nhn?titleId=183559&no=458')

# 베댓 전체를 읽는다.
doms <- remDr$findElements(using = 'css selector', 
                           '#cbox_module .u_cbox_contents')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

# 특정 베댓만 읽는다.
doms <- remDr$findElements(using = 'css selector', 
                           '#cbox_module > div > div.u_cbox_content_wrap > ul > li.u_cbox_comment.cbox_module__comment_379545008._user_id_no_5R5ni > div.u_cbox_comment_box > div > div.u_cbox_text_wrap > span.u_cbox_contents')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

#############################################################################

# 네이버 웹툰 전체 댓글 스크레이핑

# Selenium 서버를 실행한 후 크롬을 실행하고 읽어올 댓글 페이지로 이동한다.
remDr <- remoteDriver(remoteServerAddr = 'localhost', port = 4445,
                      browserName = 'chrome')
remDr$open()
remDr$navigate('https://comic.naver.com/comment/comment.nhn?titleId=183559&no=458')

# 전체 댓글을 읽어오기 위해 전체 댓글 링크를 얻어온다.
reviewBtn <- remDr$findElements(using = 'css selector', 
                                '#cbox_module > div > div.u_cbox_sort > div.u_cbox_sort_option > div > ul > li:nth-child(2) > a > span.u_cbox_sort_label')
# 클릭 이벤트를 실행해 전체 댓글 링크를 클릭한다.
sapply(reviewBtn, function(x) { x$clickElement() })
# clickElement() 함수를 사용해 얻어온 링크를 클릭하면 브라우저에서 페이지가 
# 변경되는데 페이지가 변경되기까지 Sys.sleep() 함수로 프로그램을 잠깐 멈춘다.
# 대형 포털 사이트는 너무 빠르게 요청이 들어오면 자기네 사이트가 공격당하는
# 것으로 판단할 수 있기 때문에 일정한 시간만큼 프로그램을 멈춰주는 것이 좋다.
Sys.sleep(1)

# 댓글 전체를 기억할 변수를 만들고 초기화시킨다.
review <- NULL
# 전체 댓글의 1 페이지만 읽어온다.
doms <- remDr$findElements(using = 'css selector', 
                           '#cbox_module .u_cbox_contents')
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

# 전체 댓글 페이지가 몇 페이지인지 모르기 때문에 repeat 명령을 이용해서 무한
# 루프를 돌리고 끝까지 다 읽으면 무한 루프를 탈출시킨다.
repeat {
    # 1 페이지의 댓글을 읽어왔으므로 9번 반복하며 나머지 페이지의 댓글을
    # 읽어온다.
    for(i in 4:12) {
        # 다음 페이지 댓글을 읽어오기 위해 다음 페이지로 넘겨주는 링크를
        # 얻어온다.
        # div > a:nth-child(4) => div 태그의 자식 태그로 같은 태그가 여러개
        # 있을 경우 nth-child(n) 선택자를 사용하는데 a:nth-child(4)의 의미는
        # div 태그의 자식 태그 중에서 a 태그이고 4번째 자식이라는 의미이다.
        # a:nth-child(4) => 댓글 2 페이지의 링크
        # a:nth-child(12) => 댓글 10 페이지의 링크
        nextLink <- paste('#cbox_module > div > div.u_cbox_paginate > div > a:nth-child(', i, ') > span', sep = '')
        # print(nextLink)
        nextPage <- remDr$findElements(using = 'css selector', nextLink)
        
        # 마지막 댓글 10 페이지에서 다음 댓글 페이지가 없으면 for를 탈출한다.
        if(length(nextPage) == 0) {
            break
        }
        
        # 위 if 조건이 만족하지 않았다면 다음에 읽을 댓글 페이지의 링크가 있는
        # 것이므로 다음 댓글 링크를 클릭한다.
        # 다음 댓글 페이지로 넘겨준다.
        sapply(nextPage, function(x) { x$clickElement() })
        Sys.sleep(1)
        
        # 다음 댓글 페이지의 데이터를 읽어들인다.
        doms <- remDr$findElements(using = 'css selector', 
                                   '#cbox_module .u_cbox_contents')
        result <- sapply(doms, function(x) { x$getElementText() })
        result <- unlist(result)
        # 기존에 읽어두었던 댓글 목록에 지금 읽은 페이지의 댓글을 붙여준다.
        review <- c(review, result)
    }
    
    # 다음 10 페이지의 댓글을 읽기위해 다음 10 페이지 링크를 얻어온다.
    nextLink <- '#cbox_module > div > div.u_cbox_paginate > div > a:nth-child(13) > span.u_cbox_cnt_page'
    nextPage <- remDr$findElements(using = 'css selector', nextLink)
    
    # 더 이상 읽을 다음 10 페이지가 없다면 repeat 무한 루프를 탈출시킨다.
    if(length(nextPage) == 0) {
        break
    }
    
    # 다음 10 페이지로 넘겨준다.
    sapply(nextPage, function(x) { x$clickElement() })
    Sys.sleep(1)
    
    # 새로운 10 페이지로 넘어왔으므로 첫 페이지를 읽는다.
    doms <- remDr$findElements(using = 'css selector', 
                               '#cbox_module .u_cbox_contents')
    result <- sapply(doms, function(x) { x$getElementText() })
    result <- unlist(result)
    review <- c(review, result)
}

write.csv(review, 'webtoonReview.csv')











